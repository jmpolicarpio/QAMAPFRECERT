
/*AÑADIR COLUMNA T_MAE_POLIZA*/
IF NOT EXISTs(SELECT column_name
			FROM information_schema.columns
			WHERE table_schema = 'dbo'
			and table_name = 'T_MAE_POLIZA'
			and column_name = 'POLIZA_MIGRACION') 
ALTER TABLE dbo.T_MAE_POLIZA ADD POLIZA_MIGRACION INT NULL;

/*ACTUALIZACION TABLA T_MAE_SUSCRIPCION*/
ALTER TABLE T_MAE_SUSCRIPCION ALTER COLUMN C_NUM_SUSCRIPCION INT;
	
IF NOT EXISTs(SELECT column_name
			FROM information_schema.columns
			WHERE table_schema = 'dbo'
			and table_name = 'T_MAE_SUSCRIPCION'
			and column_name = 'POL_HIBRIDO')
ALTER TABLE dbo.T_MAE_SUSCRIPCION ADD POL_HIBRIDO INT NULL;

IF NOT EXISTs(SELECT column_name
			FROM information_schema.columns
			WHERE table_schema = 'dbo'
			and table_name = 'T_MAE_SUSCRIPCION'
			and column_name = 'POLIZA_MIGRACION')
ALTER TABLE dbo.T_MAE_SUSCRIPCION ADD POLIZA_MIGRACION INT NULL;

IF NOT EXISTs(SELECT column_name
			FROM information_schema.columns
			WHERE table_schema = 'dbo'
			and table_name = 'T_MAE_SUSCRIPCION'
			and column_name = 'FLAG_POLIZA')
ALTER TABLE dbo.T_MAE_SUSCRIPCION ADD FLAG_POLIZA VARCHAR(2) NULL;

IF NOT EXISTs(SELECT column_name
			FROM information_schema.columns
			WHERE table_schema = 'dbo'
			and table_name = 'T_MAE_SUSCRIPCION'
			and column_name = 'C_NUM_POLIZA')
ALTER TABLE dbo.T_MAE_SUSCRIPCION ADD C_NUM_POLIZA VARCHAR(20) NULL;

IF NOT EXISTs(SELECT column_name
			FROM information_schema.columns
			WHERE table_schema = 'dbo'
			and table_name = 'T_MAE_SUSCRIPCION'
			and column_name = 'C_NUM_CERTIFICADO')
ALTER TABLE dbo.T_MAE_SUSCRIPCION ADD C_NUM_CERTIFICADO VARCHAR(20) NULL;

IF NOT EXISTs(SELECT column_name
			FROM information_schema.columns
			WHERE table_schema = 'dbo'
			and table_name = 'T_MAE_SUSCRIPCION'
			and column_name = 'N_ID_CANAL')
ALTER TABLE dbo.T_MAE_SUSCRIPCION ADD N_ID_CANAL INT NULL;

IF NOT EXISTs(SELECT column_name
			FROM information_schema.columns
			WHERE table_schema = 'dbo'
			and table_name = 'T_MAE_SUSCRIPCION'
			and column_name = 'N_ID_ESTABLECIMIENTO')
ALTER TABLE dbo.T_MAE_SUSCRIPCION ADD N_ID_ESTABLECIMIENTO INT NULL;

