﻿var itemCuentaAsegurado = new Object();
var aliasAplicativo;

$(function myfunction() {

    aliasAplicativo = '/' + ($("#FolderApp").val() ? $("#FolderApp").val() + "/" : "");

    var fecha = new Date()
    fecha = sumarDias(fecha, -6570);
    $(".contentEmision").css("display", "none");
    $('.fechaSistema').datetimepicker({
        format: 'DD/MM/YYYY',
        showTodayButton: false,
        maxDate: fecha
    });

    $('#divfecInicioVigencia').datetimepicker({
        format: 'DD/MM/YYYY',
        showTodayButton: false,
    });

    $("#txtFechaInicioVigencia").val(formatearFechaDDMMYYY(new Date()));

    $("#btnEmitir").click(function () {
        var msg = validarDatosMultiriesgo();
        if (msg == "") {
            swal({
                title: VJS_TITULO_ALERT,
                text: VJS_PREGUNTA_CONFIRMACION_EMITIR,
                type: "info",
                showCancelButton: true,
                cancelButtonText: "Cancelar",
                confirmButtonText: "Aceptar",
                closeOnConfirm: true,
                closeOnCancel: true
            },
                function (isConfirm) {
                    if (isConfirm) {
                        fn_FinalizarEmisionPoliza();
                    }
                });
        }
        else {
            mostrarMensaje(msg, 1, "");
        }
    });
    $("#btnCancelar").click(function () {
        swal({
            title: VJS_TITULO_ALERT,
            text: VJS_PREGUNTA_CANCELAR,
            type: "info",
            showCancelButton: true,
            cancelButtonText: "Cancelar",
            confirmButtonText: "Aceptar",
            closeOnConfirm: true,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    inicializarOfertas();
                    $(".contentEmision").css("display", "none");
                }
            });
    });

    $("#txtSumaAsegurada").change(function () {
        var valor = $(this).val();
        $(this).val(devolverNumero(valor, 2));
    });

    ////////nuevo///////
    $("#ddlTipoUsoRiesgo").change(function () {
        ruleForItem(this);
    });

    $("#ddlTipoMaterialRiesgo").change(function () {
        ruleForItem(this);
    });

    $("#txtPisosRiesgo").change(function () {
        ruleForItem(this);
    });

    ///////////////////

    $("#ddlTipoDocEntidad").change(function () {
        var idTipoDoc = $(this).val();
        if (idTipoDoc != "") {
            for (var i in listadoDocIdentidad.items) {
                if (listadoDocIdentidad.items[i].value === idTipoDoc) {
                    $("#txtNumeroDocIdentidad").prop("maxlength", listadoDocIdentidad.items[i].lon);
                    break;
                }
            }
        }
    });

    $("#ddlTipoMoneda").on("change", function () {
        var initialValue = itemCuentaAsegurado.idTipoMoneda;
        var currentValue = $(this).val();
        if (currentValue !== initialValue) {
            inicializarOfertas();
        }
    });
    $("#txtSumaAsegurada").on("change", function () {
        var initialValue = itemCuentaAsegurado.sumaAsegurada;
        var currentValue = $(this).val();
        if (currentValue !== initialValue) {
            inicializarOfertas();
        }
    });

    $("#ddlTipoMaterialRiesgo").on("change", function () {
        var valorMaterial = $(this).val();
        // Valores específicos para mostrar el mensaje
        var valoresNoAsegurables = ["645", "649", "665", "668", "670"];

        // Verificar si el valor seleccionado está en la lista de valores no asegurables
        if (valoresNoAsegurables.includes(valorMaterial)) {
            mostrarMensaje("Riesgo no asegurable", 1, "");
            $(this).val($("#ddlTipoMaterialRiesgo option:first").val()); // Inicializar el combo box (opcional: puedes establecerlo en un valor específico si es necesario)
        }
    });

    $("#ddlTipoUsoRiesgo").on("change", function () {
        var valorMaterial = $(this).val();
        // Valores específicos para mostrar el mensaje
        var valoresNoAsegurables = ["702", "704", "706"];
        // Verificar si el valor seleccionado está en la lista de valores no asegurables
        if (valoresNoAsegurables.includes(valorMaterial)) {
            mostrarMensaje("Riesgo no asegurable", 1, "");
            $(this).val($("#ddlTipoUsoRiesgo option:first").val()); // Inicializar el combo box (opcional: puedes establecerlo en un valor específico si es necesario)
        }
    });





    /*BUSCAR ASEGURADO (DNI)*/
    $('#txtNumeroDocIdentidad').change(() => {
        let tDocumentoidentidad = $('#ddlTipoDocEntidad').val();
        if (tDocumentoidentidad !== '') {
            if ($('#txtNumeroDocIdentidad').val().length > 4) {
                let documentoIdentidad = $('#txtNumeroDocIdentidad').val();
                obtenerInformacionASegurado(tDocumentoidentidad, documentoIdentidad);
            } else {
                mostrarMensaje("Número de documento Inválido o vacío.", 1, "");
            }
        } else {
            mostrarMensaje("Seleccione el tipo documento.", 1, "");
        }

    });

    /*SELECT'S ASEGURADO*/
    $('#ddlDepartamento').change(() => {
        let idDepartamento = $('#ddlDepartamento').val();
        if (idDepartamento !== '' && idDepartamento !== '0') {
            obtenerProvincia(idDepartamento, '', 'ddlProvincia');
        } else {
            $('#ddlProvincia').html("");
            $('#ddlProvincia').append($("<option></option>").val("").html("SELECCIONE LA PROVINCIA (*)"));
        }

        $('#ddlDistrito').html("");
        $('#ddlDistrito').append($("<option></option>").val("").html("SELECCIONE EL DISTRITO (*)"));
    });

    $('#ddlProvincia').change(() => {
        let idProvincia = $('#ddlProvincia').val();
        if (idProvincia !== '' && idProvincia !== '0') {
            obtenerDistrito(idProvincia, '', 'ddlDistrito');
        } else {
            $('#ddlDistrito').html("");
            $('#ddlDistrito').append($("<option></option>").val("").html("SELECCIONE EL DISTRTIO (*)"));
        }

    });

    /*SELECT'S DOMICILIO*/
    $('#ddlDepartamentoRiesgo').change(() => {
        let idDepartamento = $('#ddlDepartamentoRiesgo').val();
        if (idDepartamento !== '' && idDepartamento !== '0') {
            obtenerProvincia(idDepartamento, '', 'ddlProvinciaRiesgo');
        } else {
            $('#ddlProvinciaRiesgo').html("");
            $('#ddlProvinciaRiesgo').append($("<option></option>").val("").html("SELECCIONE LA PROVINCIA (*)"));
        }

        $('#ddlDistritoRiesgo').html("");
        $('#ddlDistritoRiesgo').append($("<option></option>").val("").html("SELECCIONE EL DISTRITO (*)"));
    });

    $('#ddlProvinciaRiesgo').change(() => {
        let idProvincia = $('#ddlProvinciaRiesgo').val();
        if (idProvincia !== '' && idProvincia !== '0') {
            obtenerDistrito(idProvincia, '', 'ddlDistritoRiesgo');
        } else {
            $('#ddlDistritoRiesgo').html("");
            $('#ddlDistritoRiesgo').append($("<option></option>").val("").html("SELECCIONE EL DISTRTIO (*)"));
        }

    });

    //$("#ddlCanal").change(function () {
    //    var idPadre = $(this).val();
    //    if (idPadre != "" && idPadre != "0") {
    //        obtenerTerritorio(idPadre);
    //    }
    //});
    $("#ddlCanal").change(function () {
        var id = $(this).val();
        if (id != "" && id != "0") {
            obtenerTerritorio(id);
        } else {
            $("#ddlTerritorio").html("");
            $("#ddlTerritorio").append($('<option></option>').val("").html("Sin registros"));
        }
    });
    $("#ddlTerritorio").change(function () {
        var id = $(this).val();
        if (id != "" && id != "0") {
            obtenerZona(id);
        } else {
            $("#ddlZona").html("");
            $("#ddlZona").append($('<option></option>').val("").html("Sin registros"));
        }
    });
    $("#ddlZona").change(function () {
        var id = $(this).val();
        if (id != "" && id != "0") {
            obtenerRegion(id);
        } else {
            $("#ddlRegion").html("");
            $("#ddlRegion").append($('<option></option>').val("").html("Sin registros"));
        }
    });

    $("#ddlRegion").change(function () {
        var id = $(this).val();
        if (id != "" && id != "0") {
            obtenerPuntoVenta(id);
        } else {
            $("#ddlPuntoVenta").html("");
            $("#ddlPuntoVenta").append($('<option></option>').val("").html("Sin registros"));
        }
    });
    $("#ddlPuntoVenta").change(function () {
        var id = $(this).val();
        if (id != "" && id != "0") {
            obtenerVendedor(id);
        } else {
            $("#ddlVendedor").html("");
            $("#ddlVendedor").append($('<option></option>').val("").html("Sin registros"));
        }
    });

    cargarEstructuraComercial();
});


function inicializarOfertas() {
    var tabla = "<table class='tabla_cotizacion'><thead><tr>";
    tabla += "<th class='borde_top' colspan='8'></th></tr>";

    tabla += "<tr><th class='seleccionarPlan columna-seleccion'></th>";
    tabla += "<th class='tituloOfertas columna-compania' style='width: 40%;' >Compañía</th>";
    tabla += "<th class='tituloOfertas columna-plan' >Plan</th>";
    tabla += "<th class='tituloOfertas columna-cuotatotal' >Prima Total</th>"
    tabla += "<th class='tituloOfertas columna-opcion' colspan='2'>Opciones</th></tr></thead>";
    $(".divPlanesEncontrados").html("<label class='planesEncontrados'>No se encontraron planes o no se realizó una búsqueda</label>");
    var registros = "<tbody><tr class='odd'><td valign='top' colspan='7' class='dataTables_empty'>No hay planes disponibles</td></tr></tbody>";
    tabla = tabla + registros + ' </table>'
    $("#divResultadoCotizacion").html("");
    $("#divResultadoCotizacion").html(tabla);

    itemCuentaAsegurado.idTarifaBase = 0;
    itemCuentaAsegurado.idPlanEmision = 0;
    itemCuentaAsegurado.primaNeta = 0;
    itemCuentaAsegurado.primaBruta = 0;
    itemCuentaAsegurado.impuestos = 0;
    itemCuentaAsegurado.idPersonaVendedor = 0;
    $(".contentEmision").css("display", "none");
}

function cargarEstructuraComercial() {
    Bloquear();

    $.ajax({
        cache: false,
        type: "GET",
        url: aliasAplicativo + "Estructura/EstructuraComercial",
        success: function (data) {
            var idCanal = data[0].idCanal;
            var idTerritorio = data[0].idTerritorio;
            var idZona = data[0].idZona;
            var idRegion = data[0].idRegion;
            var idPtoVenta = data[0].idPtoVenta;
            var idPersona = data[0].idPersona;

            if (idPersona != 0) {
                $("#ddlCanal").val(idCanal);
                $("#ddlTerritorio").val(idTerritorio);
                $("#ddlZona").val(idZona);
                $("#ddlRegion").val(idRegion);
                $("#ddlPuntoVenta").val(idPtoVenta);
                $("#ddlVendedor").val(idPersona);
            }
            Desbloquear();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        }
    });
}

function ReplicarDireccion(checkbox) {
    if (checkbox.checked) {
        $('#txtNombreViaRiesgo').val($('#txtnombreVia').val());
        /*        $('#txtValorDeclarado').val($('#txtSumaAsegurada').val());*/
        $('#ddlDepartamentoRiesgo').val($('#ddlDepartamento').val()).trigger("change");
        setTimeout(() => { $('#ddlProvinciaRiesgo').val($('#ddlProvincia').val()).trigger("change") }, 500);
        setTimeout(() => { $('#ddlDistritoRiesgo').val($('#ddlDistrito').val()).trigger("change") }, 800);
        $("#ddlTipoViaRiesgo").val($("#ddlTipoVia").val());
       /* $("#txtnombreVia").val($("#txtDireccionD").val());*/
        $("#ddlTipoNumeroRiesgo").val($("#ddlTipoNumero").val());
        $("#txtNumeroRiesgo").val($("#txtNumeroD").val()); 
    } else {
        $('#txtNombreViaRiesgo').val('');
        $('#ddlDepartamentoRiesgo').val('').trigger("change");
    }
}
//function updateValorDeclarado() {
//    var sumaAsegurada = $('#txtSumaAsegurada').val();
//  /*  var tipoMonedaTexto = $('#ddlTipoMoneda option:selected').text();*/

//    if ($('#ddlTipoMoneda').prop('selectedIndex') === 0) {
//        tipoMonedaTexto = "";
//    }
//    $('#txtValorDeclarado').val(sumaAsegurada);
//}
//$(document).ready(function () {
//    $('#txtSumaAsegurada').on('input blur', updateValorDeclarado);
//    $('#ddlTipoMoneda').on('change', updateValorDeclarado);
//    updateValorDeclarado();
//});
//$(document).ready(function () {
//    $('#txtSumaAsegurada').on('input blur', updateValorDeclarado);
//    $('#ddlTipoMoneda').on('change', updateValorDeclarado);
//    updateValorDeclarado();
//});
function updateValorDeclarado() {
    var sumaAsegurada = $('#txtSumaAsegurada').val();
    var tipoMonedaDropdown = $('#ddlTipoMoneda');
    var tipoMonedaTexto = tipoMonedaDropdown.find('option:selected').text();
    var simboloMoneda = "";
    // Mapea el texto de la moneda a su símbolo correspondiente
    switch (tipoMonedaTexto) {
        case "NUEVOS SOLES":
            simboloMoneda = "S/";
            break;
        case "DOLARES AMERICANOS":
            simboloMoneda = "$";
            break;
        default:
            simboloMoneda = "";
    }
    $('#txtValorDeclarado').val(simboloMoneda + " " + sumaAsegurada);
}
$(document).ready(function () {
    $('#txtSumaAsegurada').on('input blur', updateValorDeclarado);
    $('#ddlTipoMoneda').on('change', updateValorDeclarado);
    // Ejecutar updateValorDeclarado al cargar la página
    updateValorDeclarado();
});



//GENERAR OFERTA DE PLANES    
function buscarOfertasPlanes() {

    var msg = validarDatosIncendio();

    if (msg == "") {
        var registros = "";

        var cuotMensual;

        var tabla = "<table class='tabla_cotizacion'><thead><tr>";
        tabla += "<th class='borde_top' colspan='8'></th></tr>";

        tabla += "<tr><th class='seleccionarPlan columna-seleccion'></th>";
        tabla += "<th class='tituloOfertas columna-compania' style='width: 40%;' >Compañía</th>";
        tabla += "<th class='tituloOfertas columna-plan' >Plan</th>";
        tabla += "<th class='tituloOfertas columna-cuotatotal' >Prima Total</th>"
        tabla += "<th class='tituloOfertas columna-opcion' colspan='2'>Opciones</th></tr></thead>";

        totalRegistrosEncontrados = 0;

        var valorDec = $("#txtSumaAsegurada").val().replaceAll(",", "");
        /*var valorDec = $("#txtValorDeclarado").val().replaceAll(",", "");*/

        itemCuentaAsegurado.codProducto = ($("#ihCodProducto").val());
        itemCuentaAsegurado.opcion = $("#ihOpcionSeguro").val();
        itemCuentaAsegurado.opcionSeguro = $("#ihOpcionSeguro").val();

        itemCuentaAsegurado.valorDeclaradoPiura = valorDec;
        itemCuentaAsegurado.idTipoMoneda = $("#ddlTipoMoneda").val();
       /* itemCuentaAsegurado.nroCuotas = $("#txtNroCuotas").val();*/
        itemCuentaAsegurado.nroCuotas = 12;

        itemCuentaAsegurado.tasacionD = valorDec;
        itemCuentaAsegurado.idActividadEconomica = $("#ddlActividadEconomica").val();
        itemCuentaAsegurado.fechaInicioVigencia = $("#txtFechaInicioVigencia").val();
        itemCuentaAsegurado.sumaAsegurada = $("#txtSumaAsegurada").val();
        itemCuentaAsegurado.idTipoViaRiesgo = $("#ddlTipoViaRiesgo").val();

        var opcion = 1;

        if (opcion === 1) {
            var result;
            var parametros = `{objCotizacion : ${JSON.stringify(itemCuentaAsegurado)}}`
            $.ajax({
                cache: false,
                type: "POST",
                timeout: 600000,
                url: aliasAplicativo + "Seguro/CotizarMultiriesgoPiura",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: parametros,
                cache: false,
                success: (data) => {
                    result = data;

                    if (result.state) {
                        $.each(result.listaOfertas, function (id, option) {

                            totalRegistrosEncontrados++;
                            cuotMensual = devolverNumerosincoma(option.primBr, 2);
                            if (typeof cuotMensual == "undefined") {
                                cuotMensual = devolverNumero(0, 2);
                            }
                            registros += '<tr>';
                            registros += "<td class='seleccionarPlan'>";
                            registros += "</td>";

                            if (option.logo != null) {
                                if (option.logo.split('/').pop() != null && option.logo.split('/').pop() != "") {
                                    registros += "<td class='text-left'><img src= '" + option.logo + "' alt='Image' style='overflow: hidden; position: relative; width:50%;'/></td>";
                                } else {
                                    registros += "<td class='text-left'>" + option.nomEnti + "</td>";
                                }
                            } else {
                                registros += "<td class='text-left'>" + option.nomEnti + "</td>";
                            }
                            registros += "<td class='dato-compania'>" + option.nomOfer + "</td>";
                            registros += "<td class='dato-cuota-mensual' >" + option.moneda + "  " + devolverNumero(cuotMensual, 2) + "</td>";
                            registros += "<td class='celdaAccion text-right'>";

                            if (parseFloat(option.pNet) > 0) {
                                registros += "<a href='JavaScript:cargarDetalleCSD(" + option.idPla + ")' class='fa fa-info-circle fa-2x infoComponentes' style='margin-right: 16px;' title='Ver beneficios, coberturas y deducibles' ></a>";
                            }
                            registros += "</td>";
                            registros += '<td class="columna-emitir">';
                            if (parseFloat(option.pNet) > 0) {
                                registros += '<button class="boton-emitir" title = "Seleccionar Plan" type="button" onclick="fn_emitirPoliza(' + option.idTarifa + ',' + option.idPla + ',' + option.pNet + ',' + cuotMensual + ',' + option.imp + ',' + option.pDe + ',' + "'" + option.nomOfer + "'" + ',' + "'" + option.nomProd + "'," + "'" + option.moneda + "'," + "'" + option.nomEnti + "'," + option.indObs + ",'" + option.obs + "'" + ')"><i class="fa fa-check-square-o"></i></button > ';
                            }
                            registros += '</td>';
                            registros = registros + '</tr>';
                        });
                    }
                },
                error: (error) => {
                    console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                    $(".divPlanesEncontrados").html("<label class='planesEncontrados'>No se encontraron planes o no se realizó una búsqueda</label>");
                    registros = "<tbody><tr class='odd'><td valign='top' colspan='7' class='dataTables_empty'>No hay planes disponibles</td></tr></tbody>";
                    tabla = tabla + registros + ' </table>'
                    $("#divResultadoCotizacion").html("");
                    $("#divResultadoCotizacion").html(tabla);
                    mostrarMensaje(VJS_MSG_ERROR, 1, "");
                    Desbloquear();
                },
                complete: function (xhr, status) {
                    if (result.state) {
                        if (totalRegistrosEncontrados > 0) {
                            tabla = tabla + registros + ' </table>';
                            $("#divResultadoCotizacion").html("");
                            $("#divResultadoCotizacion").html(tabla);
                            var mensajePopupFinal = "";
                            if (totalRegistrosEncontrados == 1) {
                                $(".divPlanesEncontrados").html("<label class='planesEncontrados'>¡Planes encontrados! " + totalRegistrosEncontrados + " plan a la medida encontrado</label>");
                                mensajePopupFinal = "1 plan encontrado a medida de la información brindada ";
                            } else {
                                $(".divPlanesEncontrados").html("<label class='planesEncontrados'>¡Planes encontrados! " + totalRegistrosEncontrados + " planes a la medida encontrados</label>");
                                mensajePopupFinal = totalRegistrosEncontrados.toString() + " planes encontrados a medida de la información brindada ";
                            }
                            if (totalRegistrosEncontrados > 0) {
                                $(".seleccionarPlan").show();
                            } else {
                                $(".seleccionarPlan").hide();
                            }
                            swal({
                                title: "Planes Encontrados ",
                                text: mensajePopupFinal,
                                type: "success",
                                showCancelButton: false,
                                closeOnConfirm: false,
                                closeOnConfirm: true
                            }, function () {
                            });
                        } else {
                            $(".divPlanesEncontrados").html("<label class='planesEncontrados'>No se encontraron planes o no se realizó una búsqueda</label>");
                            registros = "<tbody><tr class='odd'><td colspan='7' >No hay planes disponibles</td></tr></tbody>";
                            tabla = tabla + registros + ' </table>'
                            $("#divResultadoCotizacion").html("");
                            $("#divResultadoCotizacion").html(tabla);
                            swal({
                                title: "Sin Información",
                                text: "No se encontraron planes a medida de la información brindada",
                                type: "info",
                                showCancelButton: false,
                                closeOnConfirm: false,
                                closeOnConfirm: true
                            }, function () {
                            });
                        }
                    } else {
                        $.each(result.property, function (index, propertyName) {
                            $("#" + propertyName).addClass("valorObligatorio");
                        });
                        mostrarMensaje(result.message, 1, "");
                    }
                    Desbloquear();
                }
            });
        }
    } else {
        mostrarMensaje(msg, 1, "");
    }
}

function obtenerInformacionASegurado(idTipoDocumento, documentoIdentidad) {
    Bloquear();
    $.ajax({
        cache: false,
        type: 'GET',
        url: `${aliasAplicativo}Seguro/ObtenerInformacionAsegurado`,
        data: {
            'idTipoDocumento': idTipoDocumento,
            'documentoIdentidad': documentoIdentidad
        },
        success: (data) => {
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
                //console.log(JSON.stringify(data));
            } else {
                $('#txtApellidoPaterno').val(data.apePaterno);
                $('#txtApellidoMaterno').val(data.apeMaterno);
                $('#txtNombres').val(data.nombre);
                $('#txtFechaNacimiento').val(data.fecNacimiento);
                if (data.idEstadoCivil != 0)
                    $('#ddlTipoEstadoCivil').val(data.idEstadoCivil);

                if (data.idTipoGenero != 0)
                    $('#ddlTipoGenero').val(data.idTipoGenero);

                $('#txtCelular').val(data.celular);
                $("#txtTelefono").val(data.telefono);
                $('#txtCorreo').val(data.correo);
                $('#txtDireccion').val(data.direccion);

                if (data.departamento.idUbigeo != 0) {
                    $('#ddlDepartamento').val(data.departamento.idUbigeo).trigger("change");
                    if (data.provincia.idUbigeo != 0) {
                        setTimeout(() => { $('#ddlProvincia').val(data.provincia.idUbigeo).trigger("change"); }, 500);
                        if (data.distrito.idUbigeo != 0) {
                            setTimeout(() => { $('#ddlDistrito').val(data.distrito.idUbigeo).trigger("change"); }, 800);
                        }
                    }
                }

                if (data.tipoVia.idTipo != 0)
                    $('#ddlTipoVia').val(data.tipoVia.idTipo);

                $('#txtNombreVia').val(data.numeroVia);

                if (data.idTipoInterior != 0)
                    $('#ddlTipoInterior').val(data.idTipoInterior);

                $('#txtInterior').val(data.interior);

                if (data.idTipoUrbanizacion != 0)
                    $('#ddlTipoUrbanizacion').val(data.idTipoUrbanizacion);

                $('#txtNombreUrbanizacion').val(data.nombreUrbanizacion);

                if (data.idTipoNumero != 0)
                    $('#ddlTipoNumero').val(data.idTipoNumero);

                $('#txtNombreNumero').val(data.nombreNumero);
            }
            
        },
        error: (jqXHR, textStatus, errorThrown) => {
            mostrarMensaje("No se encontró el asegurado.", 1, "");
            Desbloquear();
        },
        complete: (xhr, status) => {
            Desbloquear();
        }
    });
}

function obtenerProvincia(idDepartamento, idProvincia, idSelected) {
    Bloquear();
    let selected = $(`#${idSelected}`);

    $.ajax({
        cache: false,
        type: 'GET',
        url: `${aliasAplicativo}General/ObtenerProvincia`,
        data: { 'idUbigeo': idDepartamento },
        success: (data) => {
            selected.html("");
            selected.append($("<option></option>").val("").html("SELECCIONE LA PROVINCIA(*)"));

            $.each(data, (index, item) => { selected.append($(`<option></option>`).val(item.id).html(item.name)); });

            if (data.length === 0) selected.append($(`<option></option>`).val("").html("SIN REGISTROS"));

            if (idProvincia != null && idProvincia != "" && idProvincia != "0") selected.val(idProvincia);
        },
        error: (jqXHR, textStatus, errorThrown) => {
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: (xhr, status) => {
            Desbloquear();
        }
    });


}

function obtenerDistrito(idProvincia, idDistrito, idSelected) {
    Bloquear();
    let selected = $(`#${idSelected}`);

    $.ajax({
        cache: false,
        type: 'GET',
        url: `${aliasAplicativo}General/ObtenerDistrito`,
        data: { 'idUbigeo': idProvincia },
        success: (data) => {
            selected.html("");
            selected.append($("<option></option>").val("").html("SELECCIONE EL DISTRITO (*)"));

            $.each(data, (index, item) => { selected.append($(`<option></option>`).val(item.id).html(item.name)); });

            if (data.length === 0) selected.append($(`<option></option>`).val("").html("SIN REGISTROS"));

            if (idDistrito != null && idDistrito != "" && idDistrito != "0") selected.val(idProvincia);
        },
        error: (jqXHR, textStatus, errorThrown) => {
            //console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: (xhr, status) => {
            Desbloquear();
        }
    });
}

function cargarDetalleCSD(idPlan) {
    Bloquear();

    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Cotizacion/ObtenerDatosPlan',
        data: { "id": idPlan },
        cache: false,
        success: function (data) {
            if (data.id == 0) {
                console.log(JSON.stringify(data));
            } else {
                $.ajax({
                    type: 'GET',
                    url: aliasAplicativo + 'Cotizacion/PlanCoberturaCotizacion',
                    contentType: "application/json; charset=utf-8",
                    dataType: "html",
                    data: { "id": idPlan },
                    cache: false,
                    success: function (data) {
                        $("#myModal #grilla_cobertura").html("");
                        $("#myModal #grilla_cobertura").html(data);

                        $.ajax({
                            type: 'GET',
                            url: aliasAplicativo + 'Cotizacion/PlanServicioCotizacion',
                            contentType: "application/json; charset=utf-8",
                            dataType: "html",
                            data: { "id": idPlan },
                            cache: false,
                            success: function (data) {
                                $("#myModal #grilla_servicio").html("");
                                $("#myModal #grilla_servicio").html(data);

                                $.ajax({
                                    type: 'GET',
                                    url: aliasAplicativo + 'Cotizacion/PlanDeducibleCotizacion',
                                    contentType: "application/json; charset=utf-8",
                                    dataType: "html",
                                    data: { "id": idPlan },
                                    cache: false,
                                    success: function (data) {
                                        $("#myModal #grilla_deducible").html("");
                                        $("#myModal #grilla_deducible").html(data);
                                    },
                                    error: function (jqXHR, textStatus, errorThrown) {
                                        console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                                        mostrarMensaje(VJS_MSG_ERROR, 1, "");
                                        Desbloquear();
                                    },
                                    complete: function () {
                                        $("#myModal #txtCompania").html($("#grilla_cobertura #nomEntidad").val());
                                        $("#myModal #txtProducto").html($("#grilla_cobertura #desProducto").val());
                                        $("#myModal #txtPlan").html($("#grilla_cobertura #desCortaPlan").val());
                                        Desbloquear();
                                        $('#myModal').modal('show');
                                    }
                                });
                            },
                            error: function (jqXHR, textStatus, errorThrown) {
                                console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                                mostrarMensaje(VJS_MSG_ERROR, 1, "");
                                Desbloquear();
                            },
                        });
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                        mostrarMensaje(VJS_MSG_ERROR, 1, "");
                        Desbloquear();
                    },
                });
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
    });
}

function validarDatosIncendio() {
    var mensaje = "";

    var idCanal = $("#ddlCanal").val();
    if (idCanal === "") {
        $("#ddlCanal").addClass("valorObligatorio");
        mensaje += "* Seleccione el canal.";
        mensaje += "<br/>";
    } else { $("#ddlCanal").removeClass("valorObligatorio"); }

    var idTerritorio = $("#ddlTerritorio").val();
    if (idTerritorio === "") {
        $("#ddlTerritorio").addClass("valorObligatorio");
        mensaje += "* Seleccione el territorio.";
        mensaje += "<br/>";
    } else { $("#ddlTerritorio").removeClass("valorObligatorio"); }

    var idZona = $("#ddlZona").val();
    if (idZona === "") {
        $("#ddlZona").addClass("valorObligatorio");
        mensaje += "* Seleccione la zona.";
        mensaje += "<br/>";
    } else { $("#ddlZona").removeClass("valorObligatorio"); }

    var idRegion = $("#ddlRegion").val();
    if (idRegion === "") {
        $("#ddlRegion").addClass("valorObligatorio");
        mensaje += "* Seleccione la región.";
        mensaje += "<br/>";
    } else { $("#ddlRegion").removeClass("valorObligatorio"); }

    var idPtoVenta = $("#ddlPuntoVenta").val();
    if (idPtoVenta === "") {
        $("#ddlPuntoVenta").addClass("valorObligatorio");
        mensaje += "* Seleccione el punto de venta.";
        mensaje += "<br/>";
    } else { $("#ddlPuntoVenta").removeClass("valorObligatorio"); }

    var idVendedor = $("#ddlVendedor").val();
    if (idVendedor === "") {
        $("#ddlVendedor").addClass("valorObligatorio");
        mensaje += "* Seleccione el vendedor.";
        mensaje += "<br/>";
    } else { $("#ddlVendedor").removeClass("valorObligatorio"); }

    var idMoneda = $("#ddlTipoMoneda").val();
    if (idMoneda === "") {
        $("#ddlTipoMoneda").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de moneda.";
        mensaje += "<br/>";
    } else { $("#ddlTipoMoneda").removeClass("valorObligatorio"); }

    if ($("#txtSumaAsegurada").val() == "") {
        $("#txtSumaAsegurada").addClass("valorObligatorio");
        mensaje += "* Ingrese la suma asegurada.";
        mensaje += "<br/>";
    } else {
        var valorDec = $("#txtSumaAsegurada").val().replaceAll(",", "");
        if ((idMoneda == 219) && (parseInt(valorDec) > 3000000)) {
            $("#txtSumaAsegurada").addClass("valorObligatorio");
            mensaje += "* El valor ingresado a superado lo permitido.";
            mensaje += "<br/>";
        } else {
            if ((parseInt(idMoneda) == 220) && (parseFloat(valorDec) > 3000000)) {
                $("#txtSumaAsegurada").addClass("valorObligatorio");
                mensaje += "* El valor ingresado a superado lo permitido.";
                mensaje += "<br/>";
            } else {
                $("#txtSumaAsegurada").removeClass("valorObligatorio");
            }
        }
    }

    return mensaje;
}

function fn_emitirPoliza(idTarifa, idPl, primN, priBrut, mImp, monDe, nomPlan, nomProd, tiMon, nomEnti, indObs, obs) {
    itemCuentaAsegurado.idTarifaBase = idTarifa;
    itemCuentaAsegurado.idPlanEmision = idPl;
    itemCuentaAsegurado.primaNeta = primN;
    itemCuentaAsegurado.primaBruta = priBrut;
    itemCuentaAsegurado.impuestos = mImp;
    itemCuentaAsegurado.derechoEmision = monDe;
    itemCuentaAsegurado.nomPlan = nomPlan;
    itemCuentaAsegurado.nomProducto = nomProd;

    var msg = '¿Está seguro de seleccionar la oferta?';
    swal({
        title: VJS_TITULO_ALERT,
        text: msg,
        type: "info",
        showCancelButton: true,
        cancelButtonText: "Cancelar",
        confirmButtonText: "Aceptar",
        confirmButtonClass: "botonAceptarCotizar",
        closeOnConfirm: true,
        closeOnCancel: true
    },
        function (isConfirm) {
            if (isConfirm) {              
                setTimeout(function () {
                    $(".contentEmision").css("display", "");
                  
                }, 3000);
            }
        });

}

function fn_FinalizarEmisionPoliza() {

    itemCuentaAsegurado.idPersonaVendedor = $("#ddlVendedor").val();
    itemCuentaAsegurado.idTipoDocIdentidad = $("#ddlTipoDocEntidad").val();
    itemCuentaAsegurado.numDocIdentidad = $("#txtNumeroDocIdentidad").val();
    itemCuentaAsegurado.apellidoPaterno = $("#txtApellidoPaterno").val();
    itemCuentaAsegurado.apellidoMaterno = $("#txtApellidoMaterno").val();
    itemCuentaAsegurado.nombres = $("#txtNombres").val();
    itemCuentaAsegurado.fechaNacimiento = $("#txtFechaNacimiento").val();
    itemCuentaAsegurado.idTipoEstadoCivil = $('#ddlTipoEstadoCivil').val();
    itemCuentaAsegurado.idTipoSexo = $('#ddlTipoGenero').val();
    itemCuentaAsegurado.celular = $("#txtCelular").val();
    itemCuentaAsegurado.telefono = $("#txtTelefono").val();
    itemCuentaAsegurado.correo = $("#txtCorreo").val();
    itemCuentaAsegurado.idDepartamento = $("#ddlDepartamento").val();
    itemCuentaAsegurado.idProvincia = $("#ddlProvincia").val();
    itemCuentaAsegurado.idDistrito = $("#ddlDistrito").val();
    itemCuentaAsegurado.idTipoViaD = $("#ddlTipoVia").val();
    itemCuentaAsegurado.nombreVia = $("#txtnombreVia").val();
    itemCuentaAsegurado.idTipoNumero = $("#ddlTipoNumero").val();
    itemCuentaAsegurado.NumeroD = $("#txtNumeroD").val();
    itemCuentaAsegurado.idTipoInterior = $("#ddlTipoInterior").val();
    itemCuentaAsegurado.interior = $("#txtInterior").val();
    itemCuentaAsegurado.idTipoUrbanizacion = $("#ddlTipoUrbanizacion").val();
    itemCuentaAsegurado.nombreUrbanizacion = $("#txtNombreUrbanizacion").val();
    itemCuentaAsegurado.referenciaDireccion = $("#txtDireccionReferencia").val();

    itemCuentaAsegurado.idTipoUsoD = $("#ddlTipoUsoRiesgo").val();
    itemCuentaAsegurado.idTipoMaterialD = $("#ddlTipoMaterialRiesgo").val();
    itemCuentaAsegurado.idTipoViaRiesgo = $("#ddlTipoViaRiesgo").val();
    itemCuentaAsegurado.direccionD = $("#txtNombreViaRiesgo").val();
    itemCuentaAsegurado.idTipoNumeroRiesgo = $("#ddlTipoNumeroRiesgo").val();
    itemCuentaAsegurado.numeroVia = $("#txtNumeroRiesgo").val();
    itemCuentaAsegurado.idTipoInteriorD = $("#txtPisoRiesgo").val();

    itemCuentaAsegurado.idDepartamentoD = $("#ddlDepartamentoRiesgo").val();
    itemCuentaAsegurado.idProvinciaD = $("#ddlProvinciaRiesgo").val();
    itemCuentaAsegurado.idDistritoD = $("#ddlDistritoRiesgo").val();
    itemCuentaAsegurado.anioD = $("#txtAnioRiesgo").val();
    itemCuentaAsegurado.idTipoValor = $("#ddlTipoValorRiesgo").val();
    itemCuentaAsegurado.pisosD = $("#txtPisosRiesgo").val();
    itemCuentaAsegurado.sotanosD = $("#txtSotanosRiesgo").val();
    itemCuentaAsegurado.contenidoD = $("#txtContenidoRiesgo").val();

    var parametros = "{'objCotizacion': " + JSON.stringify(itemCuentaAsegurado) + " }";
    $.ajax({
        cache: false,
        type: "POST",
        timeout: 600000,
        url: aliasAplicativo + "Seguro/EmitirPolizaMultiriesgoPiura",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: parametros,
        cache: false,
        success: function (data) {
            if (typeof data.id == "undefined") {
                $.each(data.property, function (index, propertyName) {
                    $("#" + propertyName).addClass("valorObligatorio");
                });
                setTimeout(function () {
                    swal({
                        title: "Mensaje Validación",
                        html: true,
                        text: data.mensaje,
                        type: "warning",
                        showCancelButton: false,
                        confirmButtonColor: "#0f9cd6",
                        confirmButtonText: "Aceptar",
                        closeOnConfirm: false
                    });
                }, 100);
            }
            else if (data.id > 0) {
                mostrarPolizaEmitida(data.idCertificado);
                setTimeout(function () {
                    mostrarMensaje(data.mensaje, 2, "");
                }, 100);
            }
            else {
                mostrarMensaje(data.mensaje, 1, "");
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
        }, complete: function () {
            Desbloquear();
        }
    });
}

function mostrarPolizaEmitida(idCertificado) {
    var iframe = document.getElementById("iFramePoliza");
    var html = "";
    $("#tituloModalImprimir").html("Datos Generales del Certificado ");
    iframe.contentWindow.document.open();
    iframe.contentWindow.document.write(html);
    iframe.contentWindow.document.close();
    $("#iFramePoliza").attr("src", aliasAplicativo + "Emision/AbrirDetallePolizaEmitida?id=" + idCertificado);
    $("#modalEmitido").modal();
}

function CerrarIframe() {
    Bloquear();
    window.location.href = aliasAplicativo + "Seguro/MultiriesgoPiura";
}

function sumarDias(fecha, dias) {
    fecha.setDate(fecha.getDate() + dias);
    return fecha;
}
function fechaInicio() {
    //////Obtener fechas de vigencia
    var today = new Date();
    var day = today.getDate();
    var month = today.getMonth() + 1;
    var year = today.getFullYear();

    var fechaInitxt = '';
    var day_txt;
    var month_txt;

    if (day < 10) {
        day_txt = '0' + day.toString();
    } else {
        day_txt = day.toString();
    }

    if (month < 10) {
        month_txt = '0' + month.toString();
    } else {
        month_txt = month.toString();
    }

    fechaInitxt = day_txt + '/' + month_txt + '/' + year.toString();
    fechaInitxtAlt = month_txt + '/' + day_txt + '/' + year.toString();

    $("#txtFechaIni").val(fechaInitxt);
    $("#txtFechaFin").val(retornarFinVigencia(fechaInitxt));
}
function retornarFinVigencia(fecha) {
    var fecCalc = new Date(fecha.substring(3, 6) + fecha.substring(0, 3) + fecha.substring(6, 10));
    fecCalc.setMonth(fecCalc.getMonth() + 12);
    var day1 = fecCalc.getDate();
    var month1 = fecCalc.getMonth() + 1;
    var year1 = fecCalc.getFullYear();

    var day_txt1;
    var month_txt1;

    if (day1 < 10) {
        day_txt1 = '0' + day1.toString();
    } else {
        day_txt1 = day1.toString();
    }

    if (month1 < 10) {
        month_txt1 = '0' + month1.toString();
    } else {
        month_txt1 = month1.toString();
    }

    var finVig = day_txt1 + '/' + month_txt1 + '/' + year1.toString();

    return finVig;
}

function descargarReporteSSRS(idCertificado, nombreReporte) {
    $("#frmDescarga #idCertificadoTemp").val(idCertificado);
    $("#frmDescarga #tipoReporte").val(nombreReporte);
    var formulario = "";

    formulario = $("#frmDescarga").serialize();
    var valor = 0;

    Bloquear();
    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Reporte/DescargarCertificadoSSRS',
        data: formulario,
        cache: false,
        success: function (data) {
            valor = data.id;
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            if (valor === 1) {
                window.location = aliasAplicativo + 'DocumentoDescargas/DescargarReporteCertificadoGenerado';
            } else {
                mostrarMensaje(VJS_MSG_ERROR, 1, "");
            }
            Desbloquear();
        }
    });
}

function validarDatosMultiriesgo() {
    var mensaje = "";

    var idTipoDocIdentidad = $("#ddlTipoDocEntidad").val();

    if (idTipoDocIdentidad === "") {
        $("#ddlTipoDocEntidad").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de documento.";
        mensaje += "<br/>";
    } else { $("#ddlTipoDocEntidad").removeClass("valorObligatorio"); }

    var numeroDoc = $("#txtNumeroDocIdentidad").val();
    if (numeroDoc == "") {
        $("#txtNumeroDocIdentidad").addClass("valorObligatorio");
        mensaje += "* Ingrese el número de documento de Identidad.";
        mensaje += "<br/>";
    } else {
        numConError = validarTipoDocumento(idTipoDocIdentidad, numeroDoc);

        if (numConError) {
            $("#txtNumeroDocIdentidad").addClass("valorObligatorio");
            mensaje += "* El número documento es inválido";
            mensaje += "<br/>";
        } else { $("#txtNumeroDocIdentidad").removeClass("valorObligatorio"); }
    }

    if ($("#txtApellidoPaterno").val() == "") {
        $("#txtApellidoPaterno").addClass("valorObligatorio");
        mensaje += "* Ingrese el apellido paterno.";
        mensaje += "<br/>";
    } else { $("#txtApellidoPaterno").removeClass("valorObligatorio"); }

    //if ($("#txtApellidoMaterno").val() == "") {
    //    $("#txtApellidoMaterno").addClass("valorObligatorio");
    //    mensaje += "* Ingrese el apellido materno.";
    //    mensaje += "<br/>";
    //} else { $("#txtApellidoMaterno").removeClass("valorObligatorio"); }
    let apellidoMaterno = $.trim($("#txtApellidoMaterno").val());
    if (apellidoMaterno !== "") {
        $("#txtApellidoMaterno").removeClass("valorObligatorio");
    } else {
        $("#txtApellidoMaterno").removeClass("valorObligatorio");
    }


    if ($("#txtNombres").val() == "") {
        $("#txtNombres").addClass("valorObligatorio");
        mensaje += "* Ingrese el nombre.";
        mensaje += "<br/>";
    } else { $("#txtNombres").removeClass("valorObligatorio"); }

    if ($("#txtFechaNacimiento").val() == "") {
        $("#txtFechaNacimiento").addClass("valorObligatorio");
        mensaje += "* Ingrese la fecha de nacimiento.";
        mensaje += "<br/>";
    } else { $("#txtFechaNacimiento").removeClass("valorObligatorio"); }

    var celular = $("#txtCelular").val();
    if (celular == "") {
        $("#txtCelular").addClass("valorObligatorio");
        mensaje += "* Ingrese el celular.";
        mensaje += "<br/>";
    } else {
        var numConError = validarnumeroCelular(celular);
        if (numConError) {
            $("#txtCelular").addClass("valorObligatorio");
            mensaje += "* El número de celular es inválido";
            mensaje += "<br/>";
        } else { $("#txtCelular").removeClass("valorObligatorio"); }
    }

    var txtTelefono = $("#txtTelefono").val();
    if (txtTelefono != "") {
        var numConErrorD = validarNumeroTelefonoFijo(txtTelefono);
        if (numConErrorD) {
            $("#txtTelefono").addClass("valorObligatorio");
            mensaje += "* El número de telefono es inválido";
            mensaje += "<br/>";
        } else { $("#txtTelefono").removeClass("valorObligatorio"); }
    }

    if ($("#txtCorreo").val() != "") {
        var email = $.trim($("#txtCorreo").val());
        if (!validateEmail(email)) {
            $("#txtCorreo").addClass("valorObligatorio");
            mensaje += "* Ingrese un correo electrónico válido.";
            mensaje += "<br/>";
        } else {
            $("#txtCorreo").removeClass("valorObligatorio");
        }
    } else {
        $("#txtCorreo").addClass("valorObligatorio");
        mensaje += "* Ingrese un correo electrónico.";
        mensaje += "<br/>";
    }

    var idActividadEconomica = $("#ddlActividadEconomica").val();

    if (idActividadEconomica === "") {
        $("#ddlActividadEconomica").addClass("valorObligatorio");
        mensaje += "* Seleccione la actividad económica.";
        mensaje += "<br/>";
    } else { $("#ddlActividadEconomica").removeClass("valorObligatorio"); }

    //if ($("#txtDireccion").val() == "") {
    //    $("#txtDireccion").addClass("valorObligatorio");
    //    mensaje += "* Ingrese la dirección.";
    //    mensaje += "<br/>";
    //} else {
    //    $("#txtDireccion").removeClass("valorObligatorio");
    //}

    var idDepartamento = $("#ddlDepartamento").val();
    if (idDepartamento === "") {
        $("#ddlDepartamento").addClass("valorObligatorio");
        mensaje += "* Seleccione el departamento.";
        mensaje += "<br/>";
    } else { $("#ddlDepartamento").removeClass("valorObligatorio"); }

    var idProvincia = $("#ddlProvincia").val();
    if (idProvincia === "") {
        $("#ddlProvincia").addClass("valorObligatorio");
        mensaje += "* Seleccione la provincia.";
        mensaje += "<br/>";
    } else { $("#ddlProvincia").removeClass("valorObligatorio"); }

    var idDistrito = $("#ddlDistrito").val();
    if (idDistrito === "") {
        $("#ddlDistrito").addClass("valorObligatorio");
        mensaje += "* Seleccione el distrito.";
        mensaje += "<br/>";
    } else { $("#ddlDistrito").removeClass("valorObligatorio"); }

    var tipoValor = $("#ddlTipoValorRiesgo").val();
    if (tipoValor === "") {
        $("#ddlTipoValorRiesgo").addClass("valorObligatorio");
        mensaje += "* Seleccione la modalidad de Aseguramiento.";
        mensaje += "<br/>";
    } else { $("#ddlTipoValorRiesgo").removeClass("valorObligatorio"); }


    if ($("#txtNroCuotas").val() == "") {
        $("#txtNroCuotas").addClass("valorObligatorio");
        mensaje += "* Ingrese el número de cuotas.";
        mensaje += "<br/>";
    } else {
        $("#txtNroCuotas").removeClass("valorObligatorio");
    }

    var ipTipoUso = $("#ddlTipoUsoRiesgo").val();
    if (ipTipoUso === "") {
        $("#ddlTipoUsoRiesgo").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de uso del negocio.";
        mensaje += "<br/>";
    } else { $("#ddlTipoUsoRiesgo").removeClass("valorObligatorio"); }

    var idTipoMaterial = $("#ddlTipoMaterialRiesgo").val();
    if (idTipoMaterial === "") {
        $("#ddlTipoMaterialRiesgo").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de material del negocio.";
        mensaje += "<br/>";
    } else {
        if (idTipoMaterial == 645 || idTipoMaterial == 649 || idTipoMaterial == 665 || idTipoMaterial == 668 || idTipoMaterial == 669 || idTipoMaterial == 670) {
            $("#ddlTipoMaterialRiesgo").addClass("valorObligatorio");
            mensaje += "* Material de construcción no asegurable.";
            mensaje += "<br/>";
        } else {
            $("#ddlTipoMaterialRiesgo").removeClass("valorObligatorio");
        }
    }

    var idTipoVia = $("#ddlTipoVia").val();
    if (idTipoVia === "") {
        $("#ddlTipoVia").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de vía del negocio.";
        mensaje += "<br/>";
    } else { $("#ddlTipoVia").removeClass("valorObligatorio"); }

    var idTipoViaRiesgo = $("#ddlTipoViaRiesgo").val();
    if (idTipoViaRiesgo === "") {
        $("#ddlTipoViaRiesgo").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de vía riesgo del negocio.";
        mensaje += "<br/>";
    } else { $("#ddlTipoViaRiesgo").removeClass("valorObligatorio"); }

    if ($("#txtnombreVia").val() === "") {
        $("#txtnombreVia").addClass("valorObligatorio");
        mensaje += "* Ingrese el nombre tipo vía.";
        mensaje += "<br/>";
    } else { $("#txtnombreVia").removeClass("valorObligatorio"); }

    var idTipoNumero = $("#ddlTipoNumero").val();
    if (idTipoNumero === "") {
        $("#ddlTipoNumero").addClass("valorObligatorio");
        mensaje += "* Seleccione el número de vía.";
        mensaje += "<br/>";
    } else { $("#ddlTipoNumero").removeClass("valorObligatorio"); }

    var idTipoNumeroRiesgo = $("#ddlTipoNumeroRiesgo").val();
    if (idTipoNumeroRiesgo === "") {
        $("#ddlTipoNumeroRiesgo").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de número.";
        mensaje += "<br/>";
    } else { $("#ddlTipoNumeroRiesgo").removeClass("valorObligatorio"); }

    if ($("#txtNombreViaRiesgo").val() == "") {
        $("#txtNombreViaRiesgo").addClass("valorObligatorio");
        mensaje += "* Ingrese el nombre de vía del riesgo.";
        mensaje += "<br/>";
    } else {
        $("#txtNombreViaRiesgo").removeClass("valorObligatorio");
    }

    if ($("#txtNumeroD").val() == "") {
        $("#txtNumeroD").addClass("valorObligatorio");
        mensaje += "* Ingrese el número de vía.";
        mensaje += "<br/>";
    } else {
        $("#txtNumeroD").removeClass("valorObligatorio");
    }

    if ($("#txtNumeroRiesgo").val() == "") {
        $("#txtNumeroRiesgo").addClass("valorObligatorio");
        mensaje += "* Ingrese el número riesgo del negocio.";
        mensaje += "<br/>";
    } else {
        $("#txtNumeroRiesgo").removeClass("valorObligatorio");
    }

    var idDepartamentoD = $("#ddlDepartamentoRiesgo").val();
    if (idDepartamentoD === "") {
        $("#ddlDepartamentoRiesgo").addClass("valorObligatorio");
        mensaje += "* Seleccione el departamento del negocio.";
        mensaje += "<br/>";
    } else { $("#ddlDepartamentoRiesgo").removeClass("valorObligatorio"); }

    var idProvinciaD = $("#ddlProvinciaRiesgo").val();
    if (idProvinciaD === "") {
        $("#ddlProvinciaRiesgo").addClass("valorObligatorio");
        mensaje += "* Seleccione la provincia del negocio.";
        mensaje += "<br/>";
    } else { $("#ddlProvinciaRiesgo").removeClass("valorObligatorio"); }

    var idDistritoD = $("#ddlDistritoRiesgo").val();
    if (idDistritoD === "") {
        $("#ddlDistritoRiesgo").addClass("valorObligatorio");
        mensaje += "* Seleccione el distrito del riesgo.";
        mensaje += "<br/>";
    } else { $("#ddlDistritoRiesgo").removeClass("valorObligatorio"); }

    if ($("#txtAnioRiesgo").val() == "") {
        $("#txtAnioRiesgo").addClass("valorObligatorio");
        mensaje += "* Ingrese el año de construcción.";
        mensaje += "<br/>";
    } else {
        var hoy = new Date();
        var anio = hoy.getFullYear();

        if (parseInt($("#txtAnioRiesgo").val()) > anio || parseInt($("#txtAnioRiesgo").val()) < 1900) {
            $("#txtAnioRiesgo").addClass("valorObligatorio");
            mensaje += "* Ingrese un año de construcción valido.";
            mensaje += "<br/>";
        } else {
            $("#txtAnioRiesgo").removeClass("valorObligatorio");
        }
    }

    var valor = $("#txtPisosRiesgo").val();
    var valorNumero = parseInt(valor, 10);

    if (valor == "") {
        $("#txtPisosRiesgo").addClass("valorObligatorio");
        mensaje += "* Ingrese los pisos del negocio.";
        mensaje += "<br/>";
    } else {
        $("#txtPisosRiesgo").removeClass("valorObligatorio");

        // Validar si el valor es un número y está en el rango de 1 a 41
        if (isNaN(valorNumero) || valorNumero < 1 || valorNumero > 41) {
            $("#txtPisosRiesgo").addClass("valorObligatorio");
            mensaje += "* El número de pisos va entre 1 y 41.";
            mensaje += "<br/>";
        } else {
            $("#txtPisosRiesgo").removeClass("valorObligatorio");
        }
    }

    var validValues = ['0', '1', '2'];
    var valorSotano = $("#txtSotanosRiesgo").val()
    if (!validValues.includes(valorSotano)) {
        $("#txtSotanosRiesgo").addClass("valorObligatorio");
        mensaje += "* Ingrese los valores validos 0, 1 ó 2. para el número de sotanos";
        mensaje += "<br/>";
    } else {
        $("#txtSotanosRiesgo").removeClass("valorObligatorio");
    }

    if ($("#txtContenidoRiesgo").val() == "") {
        $("#txtContenidoRiesgo").addClass("valorObligatorio");
        mensaje += "* Ingrese el detalle de Descripción.";
        mensaje += "<br/>";
    } else {
        $("#txtContenidoRiesgo").removeClass("valorObligatorio");
    }

    $("#txtPisoRiesgo").removeClass("valorObligatorio");

    return mensaje;
}

function ruleForItem(obj) {
    var item = $('#' + obj.id);
    var value = parseInt(item.val());
    var name = item.attr('name').toString();

    if (name == 'ddlTipoUsoRiesgo' && [704,702,706].includes(value)) {
        item.prop('selectedIndex', 0);
        mostrarMensaje('Riesgo No Asegurable.', 1, "");
    }

    if (name == 'ddlTipoMaterialRiesgo' && [645, 649, 665, 668, 670].includes(value)) {
        item.prop('selectedIndex', 0);
        mostrarMensaje('Riesgo No Asegurable.', 1, "");
    }

    if (name == 'txtPisosRiesgo' && value > 3 && parseInt($('#ddlTipoMaterialRiesgo').val()) == 667) {
        item.val('');
        $('#ddlTipoMaterialRiesgo').prop('selectedIndex', 0);
        mostrarMensaje('Riesgo No Asegurable.', 1, "");
    }

    if (name == 'ddlTipoMaterialRiesgo' && [667].includes(value) && parseInt($('#txtPisosRiesgo').val()) > 3) {
        $('#txtPisosRiesgo').val('');
        item.prop('selectedIndex', 0);
        mostrarMensaje('Riesgo No Asegurable.', 1, "");
    }

    if (name == 'txtPisosRiesgo' && (value == 0 || value >= 42)) {
        item.val('');
        mostrarMensaje('Riesgo No Asegurable.', 1, "");
    }

    if (name == 'txtPisosRiesgo' && (value >= 5 && value < 42)) {
        $('#ddlTipoMaterialRiesgo').val(647);
    }
}