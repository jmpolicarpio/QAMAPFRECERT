﻿var aliasAplicativo;

$(function () {

    aliasAplicativo = '/' + ($("#FolderApp").val() ? $("#FolderApp").val() + "/" : "");
    AsignarFlitros();

    mostrarBandejaPlan();

    $("#frmClonar #ddlProductoClonar").prop("disabled", true);

    $("#btnNuevo").click(function () {
        abrirPlan(0,0,0,0,'');
    });

    $("#btnLimpiar").click(function () {
        $("#frmCriteriosBuscarPlan select").prop("selectedIndex",0);
        $("#frmCriteriosBuscarPlan input").val("");
        $("#ddlProductoBandeja").html('');
        $("#ddlProductoBandeja").append($('<option></option>').val("").html("Todos"));
        obtenerTipoRamo();
    });
    
    $("#btnBuscar").click(function () {
        var msj = ValidarCamposBandeja();
        if (msj == "") {
            Buscar();
        }
        else {
            mostrarMensaje(msj, 1, "");
        }
    });

    $("#ddlEntidadBandeja").change(function () {
        var id = $(this).val();
        if (id != "" && id != "0") {
            obtenerProductoEntidad(id);
        } 
        //else {
        //    obtenerTipoRamo();
        //}
    });

    $("div.bhoechie-tab-menu>div.list-group>li>a").click(function (e) {

        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });

    $("div.bhoechie-tab-menu>div.sidebar>ul.list-group>li").click(function (e) {

        e.preventDefault();
        $(this).removeClass("a.active");

        $("div.bhoechie-tab-menu>div.sidebar>ul.list-group>li>").siblings('active').removeClass("active");
        $("div.bhoechie-tab-menu>div.sidebar>ul.list-group>li>").addClass("active");
        var index = $(this).index();

       $("div.bhoechie-tab-menu>div.sidebar>ul.list-group>li").eq(index).addClass("active");

    });

    $("input[name='rdoClonarProducto']").click(function () {
        var rdoClonarProducto = $(this).val();
        if (rdoClonarProducto == 1) {
            $("#lblProducto").removeClass("etiquetaForm");
            $("#lblProducto").addClass("campo_Obligatorio").html("<label class='etiquetaForm'>Producto:</label>");
            $("#frmClonar #ddlProductoClonar").prop("disabled", false);
        } else {
            $("#lblProducto").removeClass("campo_Obligatorio");
            $("#lblProducto").addClass("etiquetaForm").html("Producto:")
            $("#ddlProductoClonar").prop("selectedIndex", 0);
            $("#frmClonar #ddlProductoClonar").prop("disabled", true);
        }
    });

    Buscar();
});

function Buscar() {
    Bloquear();
    var formularioPlanBuscar = $("#frmCriteriosBuscarPlan").serialize();

   $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Configuracion/PlanBuscar',
        data: formularioPlanBuscar,
        cache: false,
        success: function (data) {
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
            } else {
                $("#grilla").html("");
                $("#grilla").html(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            Desbloquear();
        }
    });
}

function ValidarCamposBandeja() {
    var mensaje = "";
    var opcion = 0;

    return mensaje;
}

function ActualizarEstado(id_plan, opc) {    
    if (opc == VJS_ID_ESTADO_ACTIVO || opc == VJS_ID_ESTADO_INACTIVO) { //Inactivar
        if (opc == VJS_ID_ESTADO_INACTIVO) { //Inactivar
            msg = VJS_PREGUNTA_CONFIRMACION_INACTIVAR;
        } else {
            msg = VJS_PREGUNTA_CONFIRMACION_ACTIVAR;
        }
        swal({
            title: VJS_TITULO_ALERT,
            text: msg,
            type: "info",
            showCancelButton: true,
            cancelButtonText: "Cancelar",
            confirmButtonText: "Aceptar",
            closeOnConfirm: true,
            closeOnCancel: true
        },
        function (isConfirm) {
            if (isConfirm) {
                $("#id").val(id_plan);
                $("#opcion").val(opc);
                ejecutarFormulario("frmAnular");
            }
        });
    }
    var msg = "";
    if (opc == VJS_ID_ESTADO_ANULADO) {
        msg = '¿Desea anular el plan?';

        var valor = 0;
        $.ajax({
            type: 'GET',
            url: aliasAplicativo + 'Validaciones/ValidarAnulacionPlan',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: { "idPlan": id_plan },
            cache: false,
            success: function (data) {
                valor = data;
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                mostrarMensaje(VJS_MSG_ERROR, 1, "");
                Desbloquear();
            },
            complete: function () {
                Desbloquear();
                if (valor > 0) {
                    mostrarMensaje("No se puede anular el plan, tiene pólizas asociados", 1, "");
                } else {
                    swal({
                        title: VJS_TITULO_ALERT,
                        text: msg,
                        type: "info",
                        showCancelButton: true,
                        cancelButtonText: "Cancelar",
                        confirmButtonText: "Aceptar",
                        closeOnConfirm: true,
                        closeOnCancel: true
                    },
                      function (isConfirm) {
                          if (isConfirm) {
                              $("#id").val(id_plan);
                              $("#opcion").val(opc);
                              ejecutarFormulario("frmAnular");
                          }
                      });
                }
            }
        });
    }   
}

function obtenerProductoEntidad(idEntidad) {    
    var i = 0;
    var producto = $("#ddlProductoBandeja");
    var idTipoAgrupador = $("#ddlAgrupadorBandeja").val()
    var statesProgress = $("#id_distrito-loading-progress");
    
    statesProgress.show();
    $.ajax({
        cache: false,
        type: "GET",
        url: aliasAplicativo + "Configuracion/ObtenerEntidadProducto",
        data: { "id": idEntidad },
        success: function (data) {
            if (data.id == 0) {
                producto.html('');
                producto.append($('<option></option>').val("").html("Sin Registros"));
            } else {
                producto.html('');
                producto.append($('<option></option>').val("").html("Todos"));

                $.each(data, function (id, option) {
                    producto.append($('<option></option>').val(option.id).html(option.name));
                    i = i + 1;
                });
                if (i == 0) {
                    producto.html('');
                    producto.append($('<option></option>').val("").html("Sin Registros"));
                }
            }
                  
            statesProgress.hide();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        }
    });
}

function obtenerTipoRamo() {
    Bloquear();
    var i = 0;
    var ddlRamo = $("#ddlRamoBandeja");
        
    $.ajax({
        cache: false,
        type: "GET",
        url: aliasAplicativo + "Configuracion/ObtenerTipoRamo",
        data: { "id": 0 },
        success: function (data) {
            if (data.id == 0) {
                ddlRamo.html('');
                ddlRamo.append($('<option></option>').val("").html("Sin Registros"));
            } else {
                ddlRamo.html('');
                ddlRamo.append($('<option></option>').val("").html("Todos"));
                $.each(data, function (id, option) {
                    ddlRamo.append($('<option></option>').val(option.id).html(option.name));
                    i = i + 1;
                });
                if (i == 0) {
                    ddlRamo.html('');
                    ddlRamo.append($('<option></option>').val("").html("Sin Registros"));
                }
            }
            
            Desbloquear();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        }
    });
}

function mostrarBandejaPlan() {
    //Buscar();
    $('#contenedor_dos').hide();
    $('#contenedor_tres').hide();
    $('#contenedor_uno').fadeIn("slow");
    $('.bhoechie-tab-content').html("");
}

function ocultarBandejaPlan() {
    $('#contenedor_uno').hide();
    $('#contenedor_dos').fadeIn("slow");
    $('#contenedor_tres').hide();
}

function verTabPlan(num, secPlan) {
    var idPlaGeneral = $("#idPlanGeneral").val();
    var idPlanClonar = secPlan;

    if (idPlaGeneral == "") {
        idPlaGeneral = 0;
    } else if (idPlaGeneral == "") {
        idPlaGeneral = 0;
    }

    if (idPlanClonar == "") {
        idPlanClonar = 0;
    }

    var visible = "1";
    var nombreTab;
    var metodoCarga = "";
    var opcion = $("#OpcionPlan").val(); 

    if (num != 0) {

        switch (num) {
            case "1":
                nombreTab = "Plan";
                metodoCarga = "PlanInicial";
                break;
            case "2":               
                nombreTab = "Concepto";
                metodoCarga = "PlanConceptoInicial";
                break;
            case "3":
                nombreTab = "Cobertura";
                metodoCarga = "PlanCoberturaInicial";
                break;
            case "4":
                nombreTab = "Servicios";
                metodoCarga = "PlanServicioInicial";
                break;
            case "5":
                nombreTab = "Deducibles";
                metodoCarga = "PlanDeducibleInicial";
                break;
            case "6":
                nombreTab = "Tarifacion";
                metodoCarga = "PlanTarifacionInicial";
                break;
            case "7":
                nombreTab = "FormaPago";
                metodoCarga = "PlanPagoInicial";
                break;
            case "8":
                nombreTab = "Documento";
                metodoCarga = "PlanDocumentoInicial";
                break;
            case "9":
                nombreTab = "TipoAsegurado";
                metodoCarga = "PlanTipoAseguradoInicial";
                break;
            case "10":
                nombreTab = "EvaluacionDPS";
                metodoCarga = "PlanEvaluacionDPSInicial";
                break;
            case "11":
                nombreTab = "Comision";
                metodoCarga = "PlanComisionInicial";
                break;
        }
        if (idPlaGeneral == 0) {
            if (num != "1") {
                metodoCarga = "PlanSinRegistrar";
            }
        }
        cargarPartialViewPlan(nombreTab, metodoCarga, idPlaGeneral, opcion, idPlanClonar);
    }
}

function abrirPlan(id, idEntidad, idRamo, idProducto,opcion) {
    ocultarBandejaPlan();
    $("#idPlanGeneral").val(id);
    $("#idEntidadGeneral").val(idEntidad);
    $("#idRamoGeneral").val(idRamo);
    $("#idProductoGeneral").val(idProducto);
    $("#OpcionPlan").val(opcion);

    if (id > 0) {
        $("#lblPlan").html("Actualizar Plan");
    }
    else {
        $("#lblPlan").html("Registrar Plan");
    }  
 
    $("div.bhoechie-tab-menu>div.sidebar>ul.list-group>li>a").removeClass("active");
    $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
    $("div.bhoechie-tab>div.bhoechie-tab-content").eq(0).addClass("active");
    verTabPlan("1", 0);
}

function showLoad_detalle_ajax(tab) {
    $("#tab_" + tab).html("<div class='main_load'><img src='/Imagenes/load_gris.gif' /></div>");
}

function cargarPartialViewPlan(tab, nomMetodo, idPlaGeneral, opcion, idPlanClonar) {
    Bloquear();
    $(".bhoechie-tab-content").empty();
    $(".bhoechie-tab-content").html("");    
    
    $.ajax({
        type: 'GET',
        url: aliasAplicativo + 'Configuracion/' + nomMetodo,
        contentType: "application/json; charset=utf-8",
        dataType: "html",
        data: { "id": idPlaGeneral, "opcion": opcion, "idPlanClonar": idPlanClonar },
        cache: false,
        success: function (data) {
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
            } else {
                $("#tab_" + tab).empty();
                $("#tab_" + tab).html(data);
            }
            Desbloquear();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function (xhr, status) {
            $('.scrollup').click();
             Desbloquear();
        }
    });
}

function obtenerRamoEntidadAgrupador(idEntidad, idTipoAgrupador) {
    Bloquear();
    var idRamo = $("#ddlRamoBandeja").val();
    var i = 0;
    var ddlRamo = $("#ddlRamoBandeja");
    
    $.ajax({
        cache: false,
        type: "GET",
        url: aliasAplicativo + "CargarCombos/ObtenerRamoEntidadAgrupador", //ObtenerEntidadRamo
        data: { "idEntidad": idEntidad, "idTipoAgrupador": idTipoAgrupador },
        success: function (data) {
            if (data.id == 0) {
                ddlRamo.html('');
                ddlRamo.append($('<option></option>').val("").html("Sin Registros"));
            } else {
                objetoRamo = data;
                ddlRamo.html('');
                ddlRamo.append($('<option></option>').val("").html("Todos"));
                $.each(data, function (id, option) {
                    ddlRamo.append($('<option></option>').val(option.id).html(option.name));
                    i = i + 1;
                });
                if (i == 0) {
                    ddlRamo.html('');
                    ddlRamo.append($('<option></option>').val("").html("Sin Registros"));
                } else {
                    if (idRamo != "" && idRamo != "0") {
                        $("#ddlRamoBandeja").val(idRamo);
                    }
                }
            }
            
            Desbloquear();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        }
    });
}

function AsignarFlitros() {
    var filtroCompania = $("#filtroCompania").val();
    var filtroAgrupador = $("#filtroAgrupador").val();
    var filtroRamo = $("#filtroRamo").val();
    var filtroProducto = $("#filtroProducto").val();
    var filtroDescPlan = $("#filtroDescPlan").val();
    var filtroEstado = $("#filtroEstado").val();

    if (filtroCompania != "" && filtroCompania != "0" && typeof filtroCompania != "undefined") {
        $("#ddlEntidadBandeja").val(filtroCompania);
    }
    if (filtroAgrupador != "" && filtroAgrupador != "0" && typeof filtroAgrupador != "undefined") {
        $("#ddlAgrupadorBandeja").val(filtroAgrupador);
    }
    if (filtroEstado != "" && filtroEstado != "0" && typeof filtroEstado != "undefined") {
        $("#ddlEstado").val(filtroEstado);
    }
    if (filtroProducto != "" && filtroProducto != "0" && typeof filtroProducto != "undefined") {
        $("#ddlProductoBandeja").val(filtroProducto);
    }
    if (filtroDescPlan != "" && typeof filtroDescPlan != "undefined") {
        $("#txtDesCortaPlan").val(filtroDescPlan);
    }
}

function AnularCategoria(idDetCategoriaPlan,idPlan) {
    $("#frmCategoriaTarifacion #idDetTarifaPlan").val(idDetCategoriaPlan);
    $("#frmCategoriaTarifacion #idPlanCategoriaPlan").val(idPlan);
    var mensaje = "¿Está seguro de anular la categoría del plan seleccionado?";

        swal({
            title: VJS_TITULO_ALERT,
            text: mensaje,          
            type: "info",
            showCancelButton: true,
            cancelButtonText: "Cancelar",
            confirmButtonText: "Aceptar",
            closeOnConfirm: true,
            closeOnCancel: true
        },
        function (isConfirm) {
            if (isConfirm) {
                setTimeout(function () {
                    AceptarAnulacionCategoriaPlan();
                }, 100);
                
            }
        });
}

function AceptarAnulacionCategoriaPlan() {    
    var formularioPlan = $("#frmCategoriaTarifacion").serialize();

    var id = 0;
    var mensaje = "";
    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Configuracion/PlanTarifacionCategoriaAnularPlan',
        data: formularioPlan,
        cache: false,
        success: function (data) {
            id = data.id;
            mensaje = data.mensaje.MENSAJE;
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
            } else {
                //$("#grilla").html("");
                //$("#grilla").html(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            Desbloquear();
            if (id > 0) {
                swal({
                    title: VJS_TITULO_ALERT,
                    text: mensaje,
                    type: "success",
                    showCancelButton: false,
                    cancelButtonText: "Cancelar",
                    confirmButtonText: "Aceptar",
                    closeOnConfirm: true,
                    closeOnCancel: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        setTimeout(function () {
                            verTabPlan("6", 0);
                        }, 100);
                        
                    }
                });
               
            }
        }
    });

}

function clonarPlan(id_plan, descPlan, idRamo, idProducto) {
    $("#lblProducto").removeClass("campo_Obligatorio");
    $("#lblProducto").addClass("etiquetaForm").html("Producto:")
    $("#ddlProductoClonar").prop("selectedIndex", 0);
    $("#frmClonar #ddlProductoClonar").removeClass("valorObligatorio");
    $("#frmClonar #ddlProductoClonar").prop("disabled", true);
    $("input[name='rdoClonarProducto']").filter('[value=1]').prop('checked', false);
    $("input[name='rdoClonarProducto']").filter('[value=0]').prop('checked', true);
    obtenerRamoProducto(idRamo, idProducto);
    $("#frmClonar #id").val(id_plan);
    $("#frmClonar #idProductoPlan").val(idProducto);
    $("#frmClonar #descPlanClonar").html(descPlan);
    $('#frmClonar #modalClonarPlan').modal('show');
}

function confirmaClonarPlan() {

    var id_plan = $("#frmClonar #id").val();
    var rdo = $("input[name='rdoClonarProducto']:checked").val();
    var id_producto = 0;

    if (rdo == 1) {
        id_producto = $("#frmClonar #ddlProductoClonar").val();
    }

    if (id_producto === "") {
        $("#frmClonar #ddlProductoClonar").addClass("valorObligatorio");
        mostrarMensaje("Seleccione un producto", 1, "");
        return false;
    } else {
        $("#frmClonar #ddlProductoClonar").removeClass("valorObligatorio");
    }

    $('#frmClonar #modalClonarPlan').modal('hide');
    Bloquear();
    var id_plan_clonar;

    $.ajax({
        type: 'GET',
        url: aliasAplicativo + 'Configuracion/PlanClonar',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: { "id": id_plan, "idProducto": id_producto },
        cache: false,
        success: function (data) {
            id_plan_clonar = data;
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            ocultarBandejaPlan();
            $("#idPlanGeneral").val(id_plan_clonar);
            $("#idEntidadGeneral").val(0);
            $("#idRamoGeneral").val(0);
            $("#idProductoGeneral").val(0);
            $("#OpcionPlan").val('Editar');
            $("#idPlanClonar").val(id_plan);

            $("div.bhoechie-tab-menu>div.sidebar>ul.list-group>li>a").removeClass("active");
            $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
            $("div.bhoechie-tab>div.bhoechie-tab-content").eq(0).addClass("active");
            verTabPlan("1", id_plan);
        }
    });
}

function obtenerRamoProducto(idRamo, idProducto) {
    Bloquear();
    var ddlProducto = $("#ddlProductoClonar");
    var i = 0;

    $.ajax({
        cache: false,
        type: "GET",
        url: aliasAplicativo + "CargarCombos/ObtenerProductoRamo",
        data: { "idRamo": idRamo, "idProductoConsulta": idProducto },
        success: function (data) {
            if (data.id == 0) {
                ddlProducto.html('');
                ddlProducto.append($('<option></option>').val("").html("Sin Registros"));
            } else {
                ddlProducto.html('');
                ddlProducto.append($('<option></option>').val("").html("Seleccione un producto"));
                $.each(data, function (id, option) {
                    ddlProducto.append($('<option></option>').val(option.id).html(option.name));
                    i = i + 1;
                });
                if (i == 0) {
                    ddlProducto.html('');
                    ddlProducto.append($('<option></option>').val("").html("Sin Registros"));
                } else {
                    if (idProducto != "" && idProducto != "0") {
                        $("#ddlProductoClonar").val(idProducto);
                    }
                }
            }
            
            Desbloquear();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        }
    });
}

function AbrirBitacoraAccion(id, modulo) {
    Bloquear();
    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Seguridad/AbrirBitacoraAccion',
        data: { "id": id, "modulo": modulo },
        cache: false,
        success: function (data) {
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
            } else {
                $("#divBitacoraAccion").html("");
                $("#divBitacoraAccion").html(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            Desbloquear();
            $('#modalHistorial').modal('show');
        }
    });
}