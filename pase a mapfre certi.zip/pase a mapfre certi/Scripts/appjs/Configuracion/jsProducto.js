﻿var aliasAplicativo;

$(function () {

    aliasAplicativo = '/' + ($("#FolderApp").val() ? $("#FolderApp").val() + "/" : "");

    mostrarBandejaProducto();
    mostrarBandejaProductoClonar();

    AsignarFlitros();

    $("#btnCancelar").click(function () {
        $("#id").val($("#idProducto").val());
        var msg = VJS_PREGUNTA_CANCELAR;
        swal({
            title: VJS_TITULO_ALERT,
            text: msg,
            type: "info",
            showCancelButton: true,

            cancelButtonText: "Cancelar",
            confirmButtonText: "Aceptar",

            closeOnConfirm: true,
            closeOnCancel: true
        },
        function (isConfirm) {
            if (isConfirm) {
                Bloquear();
                ejecutarFormulario("frmCancel");
                Desbloquear();
            }
        });
    });

    $("#btnNuevo").click(function () {
        abrirProducto(0);
    });
    
    $("#btnLimpiar").click(function () {
        $("#ddlEntidad").val("");
        $("#ddlAgrupador").val("");
        $("#ddlRamo").val("");

         $("#ddlEstado").val("");
        $("#txtDescProducto").val("");
     });

    $("#btnBuscar").click(function () {
        var msj = ValidarCampos();
        if (msj == "") {
            Buscar();
        }
        else {
            mostrarMensaje(msj, 1, "");
        }
    });

    $("#ddlEntidad").change(function () {
        var id = $(this).val();
        obtenerProductoRamo(id, "0");
    });

    $("div.bhoechie-tab-menu>div.list-group>a").click(function (e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });

    Buscar();

});

function Buscar() {
    Bloquear();

    var formulario = $("#frmCriteriosBuscarProducto").serialize();
    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Configuracion/ProductoBuscar',
        data: formulario,
        cache: false,
        success: function (data) {
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
            } else {
                $("#grilla").html("");
                $("#grilla").html(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            Desbloquear();
        }
    });
}

function ValidarCampos() {
    var mensaje = "";
    var opcion = 0;

    return mensaje;
}

function ActualizarEstado(id_producto, opc) {
    var continuar = false;
    $("#id").val(id_producto);
    $("#opcion").val(opc);

    var mensaje = "";

    if (opc == VJS_ID_ESTADO_ANULADO) {
        mensaje = VJS_PREGUNTA_CONFIRMACION_ANULAR;
        var valor = 0;

        $.ajax({
            type: 'GET',
            url: aliasAplicativo + 'Validaciones/ValidarAnulacionProducto',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: { "idProducto": id_producto },
            cache: false,
            success: function (data) {
                valor = data;
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                mostrarMensaje(VJS_MSG_ERROR, 1, "");
                Desbloquear();
            },
            complete: function () {
                Desbloquear();
                if (valor > 0) {
                    mostrarMensaje("No se puede anular el producto, tiene planes asociados", 1, "");
                } else {
                    swal({
                        title: VJS_TITULO_ALERT,
                        text: mensaje,
                        type: "info",
                        showCancelButton: true,
                        cancelButtonText: "Cancelar",
                        confirmButtonText: "Aceptar",
                        closeOnConfirm: true,
                        closeOnCancel: true
                    },
                  function (isConfirm) {
                      if (isConfirm) {
                          $("#id").val(id_producto);
                          $("#opcion").val(opc);
                          ejecutarFormulario("frmAnular");
                      }
                  });
                }                                           
            }
        });
    }
    
    if (opc == VJS_ID_ESTADO_ACTIVO) { //Inactivar
        mensaje = VJS_PREGUNTA_CONFIRMACION_ACTIVAR;
            swal({
                title: VJS_TITULO_ALERT,
                text: mensaje,
                type: "info",
                showCancelButton: true,
                cancelButtonText: "Cancelar",
                confirmButtonText: "Aceptar",
                closeOnConfirm: true,
                closeOnCancel: true
            },
              function (isConfirm) {
                  if (isConfirm) {
                      $("#id").val(id_producto);
                      $("#opcion").val(opc);
                      ejecutarFormulario("frmAnular");
                  }
              });
    }

    if (opc == VJS_ID_ESTADO_INACTIVO) { //Inactivar
        mensaje = VJS_PREGUNTA_CONFIRMACION_INACTIVAR;
        swal({
            title: VJS_TITULO_ALERT,
            text: mensaje,
            type: "info",
            showCancelButton: true,
            cancelButtonText: "Cancelar",
            confirmButtonText: "Aceptar",
            closeOnConfirm: true,
            closeOnCancel: true
        },
      function (isConfirm) {
          if (isConfirm) {
              $("#id").val(id_producto);
              $("#opcion").val(opc);
              ejecutarFormulario("frmAnular");
          }
      });
    } 
}

function obtenerProductoRamo(idEntidad, idRamo) {
    Bloquear();
    var i = 0;
    var ddlRamo = $("#ddlRamo");
    
    $.ajax({
        cache: false,
        type: "GET",
        url: aliasAplicativo + "Configuracion/ObtenerEntidadRamo",
        data: { "id": idEntidad },
        success: function (data) {
            ddlRamo.html('');
            ddlRamo.append($('<option></option>').val("").html("Todos"));
            $.each(data, function (id, option) {
                ddlRamo.append($('<option></option>').val(option.id).html(option.name));
                i = i + 1;
            });
            
            if (idRamo != "" && idRamo != "0") {
                $("#ddlRamo").val(idRamo);
                Buscar();
            }
            Desbloquear();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
    });
}

function verificarGuardadoIndex() {
    var mensaje = "";
    mensaje = $("#MensajeTemp").val();

    if (typeof mensaje == "undefined") {
        mensaje = '';
    }
    var tipoMensaje = $("#tipoMensajeTemp").val();

    if (typeof tipoMensaje == "undefined") {
        tipoMensaje = -1;
    }
    if (mensaje.length > 0) {
        mostrarMensaje(mensaje, tipoMensaje, null);
    }
}

function mostrarBandejaProducto() {
    //Buscar();
    $('#contenedor_tres').hide();
    $('#contenedor_dos').hide();
    $('#contenedor_uno').fadeIn("slow");
}

function ocultarBandejaProducto() {
    $('#contenedor_uno').hide();
    $('#contenedor_tres').hide();
    $('#contenedor_dos').fadeIn("slow");
}

function mostrarBandejaProductoClonar() {
    //Buscar();
    $('#contenedor_tres').hide();
    $('#contenedor_dos').hide();
    $('#contenedor_uno').fadeIn("slow");
}

function ocultarBandejaProductoClonar() {
    $('#contenedor_uno').hide();
    $('#contenedor_dos').hide();
    $('#contenedor_tres').fadeIn("slow");
}

function verTabProducto(num, secPlan) {
    var idProductoGeneral = $("#idProductoTab").val();
    var idProductoClonar = secPlan;

    if (idProductoGeneral == "") {
        idProductoGeneral = 0;
    } else if (idProductoGeneral == "") {
        idProductoGeneral = 0;
    }

    if (idProductoClonar == "") {
        idProductoClonar = 0;
    }

    var visible = "1";
    var nombreTab;
    var metodoCarga = "";

    if (num != 0) {

        switch (num) {
            case "1":
                nombreTab = "DatoParticular";
                metodoCarga = "ProductoDatoGeneral";
                break;
            case "2":
                nombreTab = "DatoEspecifico";
                metodoCarga = "ProductoDatoEspecifico";
                break;
            case "3":
                nombreTab = "ControlesTecnicos";
                metodoCarga = "ProductoDatoEspecifico";
                break;
        }
        if (idProductoGeneral == 0) {
            if (num != "1") {
                metodoCarga = "ProductoSinRegistrar";
            }
        }
        cargarPartialViewProducto(nombreTab, metodoCarga, idProductoGeneral, idProductoClonar);
    }
}

function clonarTabProducto(num) {
    var idProductoGeneral = $("#idProductoTab").val();
    if (idProductoGeneral == "") {
        idProductoGeneral = 0;
    } else if (idProductoGeneral == "") {
        idProductoGeneral = 0;
    }

    var visible = "1";
    var nombreTab;
    var metodoCarga = "";

    if (num != 0) {

        switch (num) {
            case "1":
                nombreTab = "DatoParticular";
                metodoCarga = "ProductoDatoGeneralClonar";
                break;
            case "2":
                nombreTab = "DatoEspecifico";
                metodoCarga = "ProductoDatoEspecificoClonar";
                break;
            case "3":
                nombreTab = "ControlesTecnicos";
                metodoCarga = "ProductoDatoEspecificoClonar";
                break;
        }
        if (idProductoGeneral == 0) {
            if (num != "1") {
                metodoCarga = "ProductoSinRegistrar";
            }
        }
        cargarPartialViewProductoClonar(nombreTab, metodoCarga, idProductoGeneral);
    }
}

function abrirProducto(id) {
    ocultarBandejaProducto(); 
    $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
    $("div.bhoechie-tab>div.bhoechie-tab-content").eq(1).addClass("active");    
    $("#idProductoTab").val(id);
    verTabProducto("1");
}

function clonarProducto(id) {
    
    var id_producto_clonar = 0;
    mensaje = VJS_PREGUNTA_CONFIRMACION_CLONAR;
        swal({
            title: VJS_TITULO_ALERT,
            text: mensaje,
            type: "info",
            showCancelButton: true,
            cancelButtonText: "Cancelar",
            confirmButtonText: "Aceptar",
            closeOnConfirm: true,
            closeOnCancel: true
        },
          function (isConfirm) {
              if (isConfirm) {

                  $.ajax({
                      type: 'GET',
                      url: aliasAplicativo + 'Configuracion/ProductoClonar',
                      contentType: "application/json; charset=utf-8",
                      dataType: "json",
                      data: { "id": id },
                      cache: false,
                      success: function (data) {
                          id_producto_clonar = data;
                      },
                      error: function (jqXHR, textStatus, errorThrown) {
                          console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                          mostrarMensaje(VJS_MSG_ERROR, 1, "");
                          Desbloquear();
                      },
                      complete: function () {
                          ocultarBandejaProducto();
                          $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
                          $("div.bhoechie-tab>div.bhoechie-tab-content").eq(1).addClass("active");
                          $("#idProductoTab").val(id_producto_clonar);
                          verTabProducto("1", id);
                      }
                  });
              }
          });
}

function cargarPartialViewProducto(tab, nomMetodo, idProductoGeneral, idProductoClonar) {
    $(".bhoechie-tab-content").empty();
    $(".bhoechie-tab-content").html("");
    Bloquear();
    $.ajax({
        type: 'GET',
        url: aliasAplicativo + 'Configuracion/' + nomMetodo,
        contentType: "application/json; charset=utf-8",
        dataType: "html",
        data: { "id": idProductoGeneral, "idProductoClonar": idProductoClonar },
        cache: false,
        success: function (data) {
            $("#tab_" + tab).empty();
            $("#tab_" + tab).html(data);
            Desbloquear();
        },
        error: function (data) {
            Desbloquear();
            alert("Error")
        }
    });
}

function cargarPartialViewProductoClonar(tab, nomMetodo, idProductoGeneral) {
    $(".bhoechie-tab-content").empty();
    $(".bhoechie-tab-content").html("");
    Bloquear();
    $.ajax({
        type: 'GET',
        url: aliasAplicativo + 'Configuracion/' + nomMetodo,
        contentType: "application/json; charset=utf-8",
        dataType: "html",
        data: { "id": idProductoGeneral },
        cache: false,
        success: function (data) {
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
            } else {
                $("#tab_" + tab + "_Clonar").empty();
                $("#tab_" + tab + "_Clonar").html(data);
            }
            Desbloquear();
        },
        error: function (data) {
            Desbloquear();
            alert("Error")
        }
    });
}

function obtenerRamoEntidadAgrupador(idEntidad, idTipoAgrupador) {
    Bloquear();
    var idRamo = $("#ramo_idRamo").val();
    var i = 0;
    var ddlRamo = $("#ddlRamoProducto");

    $.ajax({
        cache: false,
        type: "GET",
        url: aliasAplicativo + "CargarCombos/ObtenerRamoEntidadAgrupador", 
        data: { "idEntidad": idEntidad, "idTipoAgrupador": idTipoAgrupador, "idRamoConsulta": idRamo },
        success: function (data) {
            if (data.id == 0) {
                ddlRamo.html('');
                ddlRamo.append($('<option></option>').val("").html("Sin Registros"));
            } else {
                objetoRamo = data;
                ddlRamo.html('');
                ddlRamo.append($('<option></option>').val("").html("-- Seleccione un ramo --"));
                $.each(data, function (id, option) {
                    ddlRamo.append($('<option></option>').val(option.id).html(option.name));
                    i = i + 1;
                });
                if (i == 0) {
                    ddlRamo.html('');
                    ddlRamo.append($('<option></option>').val("").html("Sin Registros"));
                } else {
                    if (idRamo != "" && idRamo != "0") {
                        $("#ddlRamoProducto").val(idRamo);
                    }
                }
            }
            
            Desbloquear();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
    });
}

function AsignarFlitros() {
    var filtroIdEntidad = $("#filtroIdEntidad").val();
    var filtroIdAgrupador = $("#filtroIdAgrupador").val();
    var filtroIdRamo = $("#filtroIdRamo").val();
    var filtroIdEstado = $("#filtroIdEstado").val();
    var filtroDescProducto = $("#filtroDescProducto").val();

    if (filtroIdEntidad != "" && filtroIdEntidad != "0" && typeof filtroIdEntidad != "undefined") {
        $("#ddlEntidad").val(filtroIdEntidad);
        if (filtroIdRamo != "" && filtroIdRamo != "0" && typeof filtroIdRamo != "undefined") {
            obtenerProductoRamo(filtroIdEntidad, filtroIdRamo);
        }
    }
    if (filtroIdAgrupador != "" && filtroIdAgrupador != "0" && typeof filtroIdAgrupador != "undefined") {
        $("#ddlAgrupador").val(filtroIdAgrupador);
    }
    if (filtroIdEstado != "" && filtroIdEstado != "0" && typeof filtroIdEstado != "undefined") {
        $("#ddlEstado").val(filtroIdEstado);
    }
    if (filtroDescProducto != "" && typeof filtroDescProducto != "undefined") {
        $("#txtDescProducto").val(filtroDescProducto);
    }
}

function ImprimirProducto(idProducto, codProducto) {    
    Bloquear();
    var valor = 0;

    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Reporte/DescargarProductoSSRS',
        data: { "idProducto": idProducto, "codProducto": codProducto },
        cache: false,
        success: function (data) {
            valor = data.id;
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            if (valor === 1) {
                window.location = aliasAplicativo + 'DocumentoDescargas/DescargarReporteProductoGenerado?codProducto=' + codProducto;
            } else {
                mostrarMensaje(VJS_MSG_ERROR, 1, "");
            }
            Desbloquear();
        }
    });
}

function AbrirBitacoraAccion(id, modulo) {
    Bloquear();
    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Seguridad/AbrirBitacoraAccion',
        data: { "id": id, "modulo": modulo },
        cache: false,
        success: function (data) {
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
            } else {
                $("#divBitacoraAccion").html("");
                $("#divBitacoraAccion").html(data);
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            Desbloquear();
            $('#modalHistorial').modal('show');
        }
    });
}