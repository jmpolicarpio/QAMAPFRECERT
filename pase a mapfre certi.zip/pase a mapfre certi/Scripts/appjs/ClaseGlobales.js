var VJS_TITULO_ALERT = "Mensaje del Sistema"; var VJS_TITULO_ALERT_EXITO = "¡Éxito!"; var VJS_TITULO_PLANTILLA_CARGADO_EXITO = "¡Se ha cargado correctamente la plantilla!"; var VJS_PREGUNTA_CONFIRMACION_REGISTRAR = "¿Desea registrar la información?"; var VJS_PREGUNTA_CONFIRMACION_AGREGAR = "¿Desea agregar el registro?";
var VJS_PREGUNTA_CONFIRMACION_ACTUALIZAR = "¿Desea actualizar la información?";
var VJS_PREGUNTA_CONFIRMACION_ACTIVAR = "¿Desea activar el registro?";
var VJS_PREGUNTA_CONFIRMACION_INACTIVAR = "¿Desea inactivar el registro?";
var VJS_PREGUNTA_CONFIRMACION_ANULAR = "¿Desea anular el registro?";
var VJS_PREGUNTA_CONFIRMACION_QUITAR = "¿Desea quitar el registro?";
var VJS_PREGUNTA_CONFIRMACION_ENVIAR = "¿Desea enviar el registro?";
var VJS_PREGUNTA_CONFIRMACION_APROBAR = "¿Desea aprobar el registro?";
var VJS_PREGUNTA_CONFIRMACION_REVISAR = "¿Desea revisar el registro?";
var VJS_PREGUNTA_CONFIRMACION_EMITIR = "¿Desea emitir el registro?";
var VJS_PREGUNTA_CONFIRMACION_RECHAZAR = "¿Desea rechazar el registro?";
var VJS_PREGUNTA_CONFIRMACION_OBSERVAR = "¿Desea obsevar el registro?"; var VJS_PREGUNTA_CONFIRMACION_CLONAR = "¿Desea clonar el registro?"; var VJS_PREGUNTA_CANCELAR = "¿Está seguro de cancelar la acción?"; var VJS_PREGUNTA_CERRAR = "¿Está seguro de cerrar la acción?"; var VJS_PREGUNTA_GUARDAR_INFORMACION = "¿Está seguro de guardar la información?"; var VJS_PREGUNTA_CONFIRMACION_GRABAR = "¿Desea grabar la información?"; var VJS_PREGUNTA_RESTABLECER_CLAVE = "¿Desea restablecer la contraseña de usuario?"; var VJS_MENSAJE_CREACION_EXITO = "Se grabó el registro correctamente"; var VJS_MENSAJE_AGREGADO_CORRECTAMENTE = "Agregado Correctamente"; var VJS_MENSAJE_ELIMINACION_EXITO = "Se anuló el registro correctamente"; var VJS_MENSAJE_POLIZA_SECUENCIA_COPADA = "El correlativo del Plan llego a su limite, no se puede emitir la póliza"; var VJS_MENSAJE_ACEPTAR = "Aceptar"; var VJS_MENSAJE_CANCELAR = "Cancelar"; var VJS_ID_TIPO_TARIFA_ROBO_ASALTO = "274"; var VJS_ID_TIPO_TARIFA_TABLA = "236";
var VJS_ID_TIPO_RAMO_VEHICULAR = "273";
var VJS_ID_TIPO_RAMO_AGRICOLA = "287";
var VJS_ID_TIPO_INCENDIO_MULTIRIESGO = "472";
var VJS_ID_TIPO_INCENDIO = "272";
var VJS_COD_PROD_SOAT = "SO";
var VJS_COD_PROD_DESGRAVAMEN = "124";
var VJS_COD_PROD_MULTC = "12";
var VJS_COD_PROD_PROTC = "13";
var VJS_ID_TIPO_RAMO_SOAT = "704";
var VJS_ID_TIPO_RAMO_DESGRAVAMEN = "296";
var VJS_ID_TIPO_RAMO_ROBO_ASALTO = "274";
var VJS_ID_TIPO_RAMO_PROTECCION_TARJETA = "285";
var VJS_ID_TIPO_TARIFA_FIJO = "235";
var VJS_ID_TIPO_VALOR_PORCENTAJE = "239";
var VJS_ID_TIPO_VALOR_MONTO = "238";
var VJS_ANIO_MAXIMO_ANTIGUEDAD = 50;
var VJS_MSG_ERROR = "Ocurrió un error durante la operación, por favor comuníquese con soporte";
var VJS_MSG_CLAVE_VALIDACION = "Las contraseñas ingresadas no coinciden";
var VJS_ID_ESTADO_REGISTRADO = "1";
var VJS_ID_ESTADO_ENVIADO = "2";
var VJS_ID_ESTADO_PROCESADO = "3";

var VJS_ID_ESTADO_BLOQUEADO = "5";
var VJS_ID_ESTADO_APROBADO = "6";
var VJS_ID_ESTADO_OBSERVADO = "7";
var VJS_ID_ESTADO_ACTIVO = "8";
var VJS_ID_ESTADO_INACTIVO = "9";
var VJS_ID_ESTADO_CONFIRMADO = "10"; var VJS_ID_ESTADO_CERRADO = "11"; var VJS_ID_ESTADO_PENDIENTETRANSFERENCIA = "12";
var VJS_ID_ESTADO_PROCESOTRANSFERENCIA = "13"; var VJS_ID_ESTADO_TRANSFERIDO = "14"; var VJS_ID_ESTADO_EMITIDO = "15";
var VJS_ID_ESTADO_VIGENTE = "15"; var VJS_ID_ESTADO_PENDIENTEREVISAR = "16"; var VJS_ID_ESTADO_SOLICITADO = "17"; var VJS_ID_ESTADO_RECHAZADO = "18"; var VJS_ID_ESTADO_REHABILITADO = "19"; var VJS_ID_ESTADO_CAMBIADO = "20"; var VJS_ID_ESTADO_SUBSANADO = "21"; var VJS_ID_ESTADO_EXPIRADO = "22"; var VJS_ID_ESTADO_ALTA = "23"; var VJS_ID_ESTADO_BAJA = "24";
var VJS_ID_ESTADO_CANCELADO = "25";
var VJS_ID_ESTADO_ANULADO = "4";
var VJS_ID_ESTADO_NOVIGENTE = "26"; var VJS_ID_ESTADO_EMITIDO = "27"; var VJS_ID_ESTADO_VENCIDO = "28"; var VJS_ID_ESTADO_RENOVADO = "29";
var VJS_ID_ESTADO_PENDIENTEPAGO = "30"; var VJS_ID_ESTADO_PAGADO = "31"; var VJS_ID_ESTADO_DENEGADO = "32"; var VJS_ID_ESTADO_POREVALUAR = "33";
var VJS_ID_ESTADO_EXAMENES = "34"; var VJS_ID_OPCION_CLONAR = "5"; var aliasAplicativoGlobal;
var ID_TIPO_IDENTIDAD_RUCPERSONANATURAL = "392";
var ID_TIPO_IDENTIDAD_DNI = "3";
var ID_TIPO_IDENTIDAD_RUC = "362";
var ID_TIPO_IDENTIDAD_PASAPORTE = "4"; var ID_TIPO_IDENTIDAD_CE = "2";
var ID_TIPO_TERCERO_CONTRATANTE = "364";
var ID_TIPO_TERCERO_ASEGURADO = "365";
var ID_TIPO_TERCERO_RESPONSABLEPAGO = "366";
var VJS_PREGUNTA_CONFIRMACION_ELIMINAR_TARIFA_VEHICULAR = '¿Está seguro de eliminar el rango de tarifación seleccionado?'; var ID_TIPO_ROL_ENTIDAD_CANAL = 10; var ID_TIPO_ROL_ENTIDAD_COMPANIASEGURO = 9; var ID_TIPO_ROL_ENTIDAD_ENDOSATARIO = 11; var ID_TIPO_ROL_ENTIDAD_SPONSOR = 506; var VJS_ID_TIPO_COMPONENTE_COBERTURA = "225"; var VJS_ID_TIPO_COMPONENTE_SERVICIOS = "226"; var VJS_ID_TIPO_COMPONENTE_DEDUCIBLE = "227"; var VJS_ID_TIPO_FORMAPAGO_FINANCIADO = "253"; var VJS_ID_TIPO_FORMAPAGO_CONTADO = "252"; var VJS_ID_TIPO_MEDIOPAGO_EFECTIVO = "246"; var VJS_ID_TIPO_MEDIOPAGO_TARJETA = "247"; var VJS_USUARIO_SIN_CORREO = 'El Usuario seleccionado no tiene correo electrónico.<br />  Verifique correctamente dicha información'; var VJS_SESION_EXPIRADA = 'La sesión actual a expirado. vuelva a iniciar sesión'; var VJS_TITULO_PLANTILLA_VALIDO = "¡Plantilla Válida!"; var VJS_TITULO_PLANTILLA_INVALIDO = "¡Plantilla Inválida!";
var VJS_ID_TIPO_MOTIVO_ANULAR = "379";
var VJS_ID_TIPO_MOTIVO_REHABILITAR = "388";
var VJS_ID_TIPO_MOTIVO_CAMBIAR = "389";
var VJS_ID_TIPO_ACCION_PLANILLA = "741";
var VJS_ID_TIPO_MOTIVO_RECHAZAR = "390";
var VJS_ID_TIPO_MOTIVO_EMITIR = "453";
var VJS_ID_TIPO_MOTIVO_CANCELAR = "452";
var VJS_ID_TIPO_AGRUPADOR = "434";
var VJS_ID_TIPO_MONEDA_SOLES = "219";
var VJS_ID_TIPO_MONEDA_DOLARES = "220";
var VJS_ID_TIPO_POLIZA = "221";
var VJS_ID_TIPO_POLIZA_INDIVIDUAL = "222";
var VJS_ID_TIPO_POLIZA_COLECTIVO = "223";
var VJS_ID_TIPO_VIGENCIA = "174";
var VJS_ID_TIPO_VIGENCIA_ANUAL = "175";
var VJS_ID_TIPO_VIGENCIA_MENSUAL = "178";
var VJS_ID_TIPO_MONEDA_EUROS = "334";
var VJS_ID_TIPO_AGRUPADOR_CANAL = "435";
var VJS_ID_TIPO_AGRUPADOR_ENTIDAD = "436";
var VJS_ID_TIPO_AGRUPADOR_ESTADO = "437";
var VJS_ID_TIPO_AGRUPADOR_FORMAPAGO = "438";
var VJS_ID_TIPO_AGRUPADOR_MARCA = "439";
var VJS_ID_TIPO_AGRUPADOR_MES = "440";
var VJS_ID_TIPO_AGRUPADOR_MODELO = "441";
var VJS_ID_TIPO_AGRUPADOR_PLAN = "442";
var VJS_ID_TIPO_AGRUPADOR_PRODUCTO = "443";
var VJS_ID_TIPO_AGRUPADOR_ESTABLECIMIENTO = "444";
var VJS_ID_TIPO_AGRUPADOR_RAMO = "445";
var VJS_ID_TIPO_AGRUPADOR_NOMBRE = "446";
var VJS_ID_TIPO_ROL_VENDEDOR = "312";
var VJS_ID_TIPO_ROL_EMISOR = "311";
var VJS_ID_TIPO_ROL_CONFIGURADOR = "451";
var VJS_ID_TIPO_ROL_AJUSTADOR = "688";
var VJS_ID_TIPO_ADJUNTO_PDF = "411";
var VJS_ID_TIPO_CLIENTE_EMPLEADOS = "231";
var VJS_ID_TIPO_TARJETA = "407";
var VJS_ID_TIPO_TARJETA_VISA = "408";
var VJS_ID_TIPO_TARJETA_MASTERCARD = "409";
var VJS_ID_TIPO_TARJETA_SILVERMASTERCARD = "512";
var VJS_ID_TIPO_TARJETA_PLATINUMVISA = "513";
var VJS_ID_TIPO_TARJETA_OH = "540";
var VJS_ID_TIPO_TARJETA_MASTERCARDINTERNACIONAL = "541";
var VJS_ID_TIPO_TARJETA_RIPLEY = "542";
var VJS_ID_TIPO_TARJETA_SILVERVISA = "543";
var VJS_ID_TIPO_TARJETA_GOLDVISA = "544";
var VJS_ID_TIPO_TARJETA_GOLDMASTERCARD = "545";
var VJS_ID_TIPO_TARJETA_OHMASTERCARD = "546";
var VJS_ID_TIPO_MOTIVO_ENVIAR_SINIESTRO = "551";
var VJS_ID_TIPO_MOTIVO_APROBAR_SINIESTRO = "552";
var VJS_ID_TIPO_MOTIVO_RECHAZAR_SINIESTRO = "553";
var VJS_ID_TIPO_MOTIVO_CERRAR_SINIESTRO = "554";
var VJS_ID_TIPO_MOTIVO_ANULAR_SINIESTRO = "555";
var VJS_ID_TIPO_MOTIVO_REABRIR_SINIESTRO = "556";
var VJS_ID_PERFIL_ADMINISTRADOR = "1";
var VJS_ID_TIPO_DECLARANTE_MISMO = "107";
var VJS_ID_TIPO_MEDIOINFORMACION_CORREO = "115";
var VJS_ID_TIPO_MEDIOINFORMACION_SMS = "116";
var VJS_ID_TIPO_AGRUPADOR_VEHICULAR = "268";
var VJS_ID_TIPO_AGRUPADOR_VIDA = "269";
var VJS_ID_TIPO_AGRUPADOR_RRGG = "270";
var VJS_ID_TIPO_ASEGURADO_TITULAR = "640";
var VJS_ID_TIPO_ASEGURADO_CONYUGUE = "641";
var VJS_ID_TIPO_MOTIVO_APROBAR_SUSCRIPCION = "136";
var VJS_ID_TIPO_MOTIVO_RECHAZAR_SUSCRIPCION = "137";
var VJS_MSG_ERROR_APROBACION = "Control se rechazó correctamente. Se emitirá la poliza en estado rechazado";

$(function () { aliasAplicativoGlobal = '/' + ($("#FolderApp").val() ? $("#FolderApp").val() : ""); if (aliasAplicativoGlobal === null || aliasAplicativoGlobal === '/') { aliasAplicativoGlobal = ""; } });
function justNumbers(e) {
    var keynum = window.event ? window.event.keyCode : e.which; if ((keynum == 8) || (keynum == 46))
        return true; return /\d/.test(String.fromCharCode(keynum));
}
function validarAlfaNumero(e) {
    var keynum = window.event ? window.event.keyCode : e.which; if ((keynum >= 48) && (keynum <= 57) || (keynum >= 65) && (keynum <= 90) || (keynum >= 97) && (keynum <= 122) || keynum == 8 || keynum == 45 || keynum == 37 || keynum == 39 || keynum == 32 || keynum == 44 || keynum == 46)
        return true; return false;
}
function validarAlfaNumerico(e) {
    var keynum = window.event ? window.event.keyCode : e.which; var regex = new RegExp("^[a-zA-Z ñóéíúá´ÑÓÉÍÚÁ 0-9]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode); if (!regex.test(key)) { event.preventDefault(); return false; } else { return true; }
}
function validarAlfaNumericoRazonSocial(e) {
    var keynum = window.event ? window.event.keyCode : e.which; var regex = new RegExp("^[a-zA-Z ñóéíúá´ÑÓÉÍÚÁ 0-9 .&]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode); if (!regex.test(key)) { event.preventDefault(); return false; } else { return true; }
}
function validarAlfaNumericoDireccion(e) {
    var keynum = window.event ? window.event.keyCode : e.which;
    var regex = new RegExp("^[a-zA-Z ñóéíúáÑÓÉÍÚÁ 0-9- ._/,]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
    if (!regex.test(key)) { event.preventDefault(); return false; } else { return true; }
}
function alfaNumericoCaracteres(e) {
    var keynum = window.event ? window.event.keyCode : e.which; var regex = new RegExp("^[a-zA-Z ñóéíúá´ÑÓÉÍÚÁ]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode); if (!regex.test(key)) { event.preventDefault(); return false; } else { return true; }
}
function alfaNumericoCaracteres(e) {
    var keynum = window.event ? window.event.keyCode : e.which; if ((keynum >= 48) && (keynum <= 57) || (keynum >= 65) && (keynum <= 90) || (keynum >= 97) && (keynum <= 122) || keynum == 8 || keynum == 45 || keynum == 37 || keynum == 39 || keynum == 32 || keynum == 44 || keynum == 46)
        return true; return false;
}
function soloNumerosEnteros(e) {
    var keynum = window.event ? window.event.keyCode : e.which; if (event.shiftKey) { event.preventDefault(); }
    var regex = new RegExp("^[0-9]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode); if (!regex.test(key)) { event.preventDefault(); return false; }
    return /\d/.test(String.fromCharCode(keynum));
}
function numerosEnterosyLetras(e) {
    var keynum = window.event ? window.event.keyCode : e.which; if (event.shiftKey) { event.preventDefault(); }
    var regex = new RegExp("^[a-zA-Z0-9]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode); if (!regex.test(key)) { event.preventDefault(); return false; } else { return true; }
}
function validarTextoParaNombre(e) {
	var keynum = window.event ? window.event.keyCode : e.which;
    var regex = new RegExp("^[a-zA-Z ñóéíúá´ÑÓÉÍÚÁ]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode); if (!regex.test(key)) { event.preventDefault(); return false; } else { return true; }
}
function validarTextoParaNombresRuc(e) {
    var keynum = window.event ? window.event.keyCode : e.which;
    var regex = new RegExp("^[a-zA-Z ñóéíúá´ÑÓÉÍÚÁ.]+$");
    var key = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (!regex.test(key)) {
        e.preventDefault();
        return false;
    } else {
        return true;
    }
}



function soloLetrasyEspacio(e) {
    var keynum = window.event ? window.event.keyCode : e.which; if (event.shiftKey) { event.preventDefault(); }
    var regex = new RegExp("^[a-zA-Z ]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode); if (!regex.test(key)) { event.preventDefault(); return false; }
    return /\d/.test(String.fromCharCode(keynum));
}
function soloLetras(e) {
    if (event.shiftKey) { event.preventDefault(); }
    var regex = new RegExp("^[a-zA-Z]+$");
    var key = String.fromCharCode(!event.charCode ? event.which : event.charCode); if (!regex.test(key)) { event.preventDefault(); return false; }
    return /\d/.test(String.fromCharCode(keynum));
}
function mostrarMensaje(mensaje, tipoMensaje, formularioOMetodo) {
    if (tipoMensaje == 1) { var unique_id = $.gritter.add({ title: VJS_TITULO_ALERT, text: mensaje, image: aliasAplicativoGlobal + '/Imagenes/aviso.png', time: '3000', class_name: 'my-sticky-class' }); }
    if (tipoMensaje == 2) {
        swal({
            title: VJS_TITULO_ALERT_EXITO,
            html: true, text: mensaje, type: "success"
        }, function () {
            if (formularioOMetodo.length > 0) {
                $("#" + formularioOMetodo).submit();
            }
        });
    }
    if (tipoMensaje == 3) {
        swal({
            title: VJS_TITULO_ALERT,
            html: true,
            text: mensaje,
            type: "info"
        }, function () {
            if (formularioOMetodo.length > 0) {
                //(formularioOMetodo)();
                fn_VolverCargarPagina();
            }
        });
    }
    if (tipoMensaje == 4) {
        swal({
            title: VJS_TITULO_ALERT_EXITO,
            html: true,
            text: mensaje,
            type: "success"
        }, function () {
            if (formularioOMetodo.length > 0) {
                fn_VolverCargarPagina();
            }
        });
    }
}


function ejecutarFormulario(formulario) {
    Bloquear(); if (formulario.length > 0) { $("#" + formulario).submit(); }
    console.log('confirmed'); Desbloquear(); return false;
}
function validateEmail(sEmail) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/; if (filter.test(sEmail)) { return true; }
    else { return false; }
}
function validateEmail($email) { var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/; return emailReg.test($email); }
function devolverNumero(id, dec) { var fld = accounting.format(id, { symbol: "", precision: dec, thousand: ",", decimal: ".", format: { pos: "%s %v", neg: "%s (%v)", zero: "%s  --" } }); return fld; }
function devolverNumerosincoma(id, dec) { var fld = accounting.format(id, { symbol: "HK$", precision: dec, thousand: "", format: { pos: "%s %v", neg: "%s (%v)", zero: "%s --" } }); return fld; }
function validarFormatoFecha(campo) { var RegExPattern = /^\d{1,2}\/\d{1,2}\/\d{2,4}$/; if ((campo.match(RegExPattern)) && (campo != '')) { return true; } else { return false; } }
function existeFecha(fecha) {
    var fechaf = fecha.split("/"); var day = fechaf[0]; var month = fechaf[1]; var year = fechaf[2]; var date = new Date(year, month, '0'); if ((day - 0) > (date.getDate() - 0)) { return false; }
    return true;
}
function existeFecha2(fecha) { var fechaf = fecha.split("/"); var d = fechaf[0]; var m = fechaf[1]; var y = fechaf[2]; return m > 0 && m < 13 && y > 0 && y < 32768 && d > 0 && d <= (new Date(y, m, 0)).getDate(); }
function formatearFecha(fecha) {
    var anio = fecha.getFullYear(); var mes = fecha.getMonth() + 1; var dia = fecha.getDate(); if (mes < 10) { mes = "0" + mes; }
    if (dia < 10) { dia = "0" + dia; }
    fecRetorno = mes + "/" + dia + "/" + anio
    return fecRetorno;
}
function formatearFechaDDMMYYY(fecha) {
    var anio = fecha.getFullYear(); var mes = fecha.getMonth() + 1; var dia = fecha.getDate(); if (mes < 10) { mes = "0" + mes; }
    if (dia < 10) { dia = "0" + dia; }
    fecRetorno = dia + "/" + mes + "/" + anio
    return fecRetorno;
}
function ValidarFecha(fecha, id) { if (validarFormatoFecha(fecha)) { if (existeFecha(fecha)) { } else { mostrarMensaje("La fecha introducida no existe.", 1, ""); document.getElementById(id).value = ""; } } else { mostrarMensaje("El formato de la fecha es incorrecto.", 1, ""); document.getElementById(id).value = ""; } }
function Bloquear() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Procesando ...</h5>' }); }
function Desbloquear() { $.unblockUI(); }
function bloquearBuscandoPlanes() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Buscando planes disponibles ...</h5>' }); }
function bloquearCargandoPlantilla() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Cargando plantilla ...</h5>' }); }
function bloquearSegundos() { $.blockUI({ message: '<h4><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Por favor, espere uno segundos...</h2>' }); }
function bloquearGrabando() { $.blockUI({ message: '<h4><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Grabando ...</h2>' }); }
function bloquearValidandoInformacion() { $.blockUI({ message: '<h4><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Validando información ...</h2>' }); }
function bloquearEnviandoCotizacion() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Enviando cotización ...</h5>' }); }
function bloquearBuscandoPrePolizas() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Buscando Pre-Polizas ...</h5>' }); }
function bloquearCargandoInformacionPlan() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Cargando Plantilla ...</h5>' }); }
function bloquearGuardandoInformacion() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Guardando Información ...</h5>' }); }
function bloquearCargandoInformacion() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Cargando Información ...</h5>' }); }
function bloquearBuscandoInformacion() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Buscando Información ...</h5>' }); }
function bloquearEnvioCorreo() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Enviar Correo Electrónico ...</h5>' }); }
function bloquearDescargandoInformacion() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Preparando información... </h5>' }); }
function bloquearValidandoCredenciales() { $.blockUI({ message: '<h5><img src="' + aliasAplicativoGlobal + '/Imagenes/load_gris.gif" /> Validando Credenciales...</h5>' }); }
function formatearDecimal(Numero, Decimales) {
    var pot = Math.pow(10, Decimales); var num = parseInt(Numero * pot) / pot; var nume = num.toString().split('.'); var entero = nume[0]; var decima = nume[1]; var fin; if (decima != undefined) { fin = Decimales - decima.length; }
    else { decima = ''; fin = Decimales; }
    for (i = 0; i < fin; i++)
        decima += String.fromCharCode(48); var buffer = ""; var marca = entero.length - 1; var chars = 1; while (marca >= 0) {
            if ((chars % 4) == 0) { buffer = "." + buffer; }
            buffer = entero.charAt(marca) + buffer; marca--; chars++;
        }
    if (decima != '')
        num = buffer + '.' + decima; else
        num = buffer; return num;
}
//const key = CryptoJS.enc.Utf8.parse("8080808080808080");
//const iv = CryptoJS.enc.Utf8.parse("8080808080808080");
function mostrarCargaInformacion() { $(".box_block").fadeIn(100, function () { $(".box_block").css("opacity", "1"); }); }
function cerrarCargaInformacion() { $(".box_block").fadeOut(); }
function validarFechaMayoroIgual(fechaInicial, fechaFinal) {
    valuesStart = fechaInicial.split("/"); valuesEnd = fechaFinal.split("/"); var dateStart = new Date(valuesStart[2], (valuesStart[1] - 1), valuesStart[0]); var dateEnd = new Date(valuesEnd[2], (valuesEnd[1] - 1), valuesEnd[0]); if (dateStart >= dateEnd) { return 0; }
    return 1;
}
function validarFechaMayor(fechaInicial, fechaFinal) {
    valuesStart = fechaInicial.split("/"); valuesEnd = fechaFinal.split("/"); var dateStart = new Date(valuesStart[2], (valuesStart[1] - 1), valuesStart[0]); var dateEnd = new Date(valuesEnd[2], (valuesEnd[1] - 1), valuesEnd[0]); if (dateStart > dateEnd) { return 0; }
    return 1;
}
function ValidateNumberKeyPress(field, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode; var keychar = String.fromCharCode(charCode); if (charCode > 31 && (charCode < 48 || charCode > 57) && keychar != "." && keychar != "-") { return false; }
    if (keychar == "." && field.value.indexOf(".") != -1) { return false; }
    if (keychar == "-") { if (field.value.indexOf("-") != -1) { return false; } else { var caretPos = getCaretPosition(field); if (caretPos != 0) { return false; } } }
    return true;
}
function obtenerFechaActual() { var d = new Date(); var mes = d.getMonth() + 1; var dia = d.getDate(); var fechaActual = (('' + dia).length < 2 ? '0' : '') + dia + '/' + (('' + mes).length < 2 ? '0' : '') + mes + '/' + d.getFullYear(); return fechaActual; }
function validarFechaSoloMayor(fechaInicial, fechaFinal) {
    valuesStart = fechaInicial.split("/"); valuesEnd = fechaFinal.split("/"); var dateStart = new Date(valuesStart[2], (valuesStart[1] - 1), valuesStart[0]); var dateEnd = new Date(valuesEnd[2], (valuesEnd[1] - 1), valuesEnd[0]); if (dateStart < dateEnd) { return 0; }
    return 1;
}
$(document).on('keyup keypress', 'form input[type="text"]', function (e) { if (e.keyCode == 13) { e.preventDefault(); return false; } }); function validarTarjeta(tipoTarjeta, numeroTarjeta) {
    var as_tipo = tipoTarjeta; var as_value = numeroTarjeta; var p_cNumDocRef = as_value; var p_cCodEntFinanc = as_tipo; var bValidoPrefijo = false; var bValidoLongitud = false; var cValidaciones = ''; if (as_tipo == VJS_ID_TIPO_TARJETA_RIPLEY)
        cValidaciones = '9604,16'; if (as_tipo == VJS_ID_TIPO_TARJETA_SILVERVISA)
        cValidaciones = '450034,16'; if (as_tipo == VJS_ID_TIPO_TARJETA_SILVERMASTERCARD)
        cValidaciones = '525474,16'; if (as_tipo == VJS_ID_TIPO_TARJETA_GOLDVISA)
        cValidaciones = '450035,16'; if (as_tipo == VJS_ID_TIPO_TARJETA_GOLDMASTERCARD)
        cValidaciones = '542020,16'; if (as_tipo == VJS_ID_TIPO_TARJETA_VISA)
        cValidaciones = '4,16'; if (as_tipo == VJS_ID_TIPO_TARJETA_MASTERCARD)
        cValidaciones = '51-55 60 96,16'; if (as_tipo == VJS_ID_TIPO_TARJETA_OH)
        cValidaciones = '920101 920202,16'; if (as_tipo == VJS_ID_TIPO_TARJETA_OHMASTERCARD)
        cValidaciones = '524601,16'; var nPosCaracter = cValidaciones.indexOf(','); var cPrefijos = cValidaciones.substring(0, nPosCaracter); var cLongitudes = cValidaciones.substring(nPosCaracter + 1, cValidaciones.length); if ((cValidaciones.length) > 0) {
            nPosEspacio = 1; nPosInicio = 0; while (nPosEspacio > 0) {
                nPosEspacio = cPrefijos.indexOf(' '); if (nPosEspacio > 0)
                    cPrefijo = cPrefijos.substring(nPosInicio, nPosEspacio); else
                    cPrefijo = cPrefijos; nPosCaracter2 = cPrefijo.indexOf('-'); if (nPosCaracter2 > 0) {
                        cPrefijo1 = cPrefijo.substring(0, nPosCaracter2); cPrefijo2 = cPrefijo.substring(nPosCaracter2 + 1, cPrefijo.length); nLongPrefijo = cPrefijo1.length; nPrefijoNumDocRef = p_cNumDocRef.substring(0, nLongPrefijo); if (cPrefijo2.indexOf(',') > 0)
                            cPrefijo2 = cPrefijo2.substring(0, cPrefijo2.length); nPrefijo1 = cPrefijo1; nPrefijo2 = cPrefijo2; if ((nPrefijo2 >= nPrefijoNumDocRef) && (nPrefijo1 <= nPrefijoNumDocRef))
                            bValidoPrefijo = true;
                    } else {
                    if (cPrefijo.indexOf(',') > 0)
                        cPrefijo = cPrefijo.substring(0, cPrefijo.length); nLongPrefijo = cPrefijo.length; nPrefijoNumDocRef = p_cNumDocRef.substring(0, nLongPrefijo); if (cPrefijo == nPrefijoNumDocRef)
                        bValidoPrefijo = true;
                }
                cPrefijos = cPrefijos.substring(nPosEspacio + 1, cPrefijos.length);
            }
            nPosEspacio = 1; nPosInicio = 0; while ((nPosEspacio > 0) && (bValidoPrefijo)) {
                nPosEspacio = cLongitudes.indexOf(' '); if (nPosEspacio > 0)
                    cLongitud = cLongitudes.substring(nPosInicio, nPosEspacio); else
                    cLongitud = cLongitudes; nPosCaracter2 = cLongitud.indexOf('-'); if (nPosCaracter2 > 0) {
                        cLongitud1 = cLongitud.substring(0, nPosCaracter2); cLongitud2 = cLongitud.substring(nPosCaracter2 + 1, cLongitud.length); if ((cLongitud1 <= p_cNumDocRef.length) && (cLongitud2 >= p_cNumDocRef.length))
                            bValidoLongitud = true;
                    } else {
                    if (cLongitud == p_cNumDocRef.length)
                        bValidoLongitud = true;
                }
                cLongitudes = cLongitudes.substring(nPosEspacio + 1, cLongitudes.length);
            }
        }
    nSumTarjeta = 0; nLongitudCadena = (p_cNumDocRef.length); if ((as_tipo != '50') && (as_tipo != '60')) {
        for (contador_val = 1; contador_val <= nLongitudCadena; contador_val++) {
            if ((contador_val % 2) == 0) {
                li_div = 10; li_dig = 0; desde = nLongitudCadena - contador_val; li_tmp = (p_cNumDocRef.substring(desde, desde + 1)) * 2; li_dig = li_tmp; if (li_tmp > 9) { li_tmp1 = li_tmp / li_div; li_tmp2 = li_tmp % 10; li_dig = li_tmp1 + li_tmp2; }
                nDigitoaux = li_dig; nSumTarjeta = parseInt(nSumTarjeta) + parseInt(nDigitoaux);
            } else { desde = nLongitudCadena - contador_val; nDigitoaux2 = (p_cNumDocRef.substring(desde, desde + 1)); nSumTarjeta = parseInt(nSumTarjeta) + parseInt(nDigitoaux2); }
        }
    }
    if (((nSumTarjeta % 10) == 0) && bValidoLongitud && bValidoPrefijo)
        cMessage = true; else
        cMessage = false; return cMessage;
}
function hoyFecha() { var hoy = new Date(); var dd = hoy.getDate(); var mm = hoy.getMonth() + 1; var yyyy = hoy.getFullYear(); dd = addZero(dd); mm = addZero(mm); return dd + '/' + mm + '/' + yyyy; }
function addZero(i) {
    if (i < 10) { i = '0' + i; }
    return i;
}
function validateClaveSegura(clv, lng) {
    var longitud = false, minuscula = false, numero = false, mayuscula = false, simbolo = false; var pswd = clv
    if (pswd.length < lng) { $('#length').removeClass('valid').addClass('invalid'); } else { $('#length').removeClass('invalid').addClass('valid'); longitud = true; }
    if (pswd.match(/[A-z]/)) { $('#letter').removeClass('invalid').addClass('valid'); minuscula = true; } else { $('#letter').removeClass('valid').addClass('invalid'); }
    if (pswd.match(/[A-Z]/)) { $('#capital').removeClass('invalid').addClass('valid'); mayuscula = true; } else { $('#capital').removeClass('valid').addClass('invalid'); }
    if (pswd.match(/\d/)) { $('#number').removeClass('invalid').addClass('valid'); numero = true; } else { $('#number').removeClass('valid').addClass('invalid'); }
    if (pswd.match(/[$@#$!%*?&;+}{-]/)) { $('#number').removeClass('invalid').addClass('valid'); simbolo = true; } else { $('#number').removeClass('valid').addClass('invalid'); }
    if (longitud && minuscula && numero && mayuscula && simbolo) { return true; } else { return false; }
}
var listadoDocIdentidad = {
    "valores": "Listado Doc. Identidad",
    "items": [{ "value": "2", "desc": "Carnet", "lon": "12", "lonmin": "5" },
        { "value": "3", "desc": "DNI", "lon": "8", "lonmin": "8" },
        { "value": "4", "desc": "Pasaporte", "lon": "12", "lonmin": "6" },
        { "value": "392", "desc": "RUC PN", "lon": "11", "lonmin": "5" },
        { "value": "362", "desc": "RUC", "lon": "11", "lonmin": "11" }    ]
};


function validarTipoDocumento(idTipoDoc, numDoc) {
    debugger;
    var numConError = false;
    for (var i in listadoDocIdentidad.items) {
        if (listadoDocIdentidad.items[i].value === idTipoDoc) {
            if (numDoc.length < listadoDocIdentidad.items[i].lonmin || numDoc.length > listadoDocIdentidad.items[i].lon) {
                numConError = true;                
                break;
            }
            break;
        }
    }
    if (idTipoDoc == ID_TIPO_IDENTIDAD_RUC) {
        if (numDoc != "") {
            var valorInicial = numDoc.substring(0, 2);
            if (valorInicial.substring(0, 2) != "20") {
                numConError = true;                
            }
        }
    }
    else if (idTipoDoc == ID_TIPO_IDENTIDAD_RUCPERSONANATURAL) {
        if (numDoc != "") {
            if (numDoc.substring(0, 2) != "10") {
                numConError = true;                
            }
        }
    }
    return numConError;
}
function validarnumeroCelular(numeroCel) {
    var numConError = false;

    if (numeroCel != null) {
        if (numeroCel.length != 9) {
            numConError = true;
        } else {
            var prefijo = numeroCel.substring(0, 1);
            if (prefijo != "9") {
                numConError = true;
            }
        }

    } else {
        numConError = true;
    }
    return numConError;
}

function obtenerTipoDocumentoIdentidadFCTrama(idTipoDoc) {
    var idValorReturn = "0";
    if (idTipoDoc == "21") { idValorReturn = "3"; }
    if (idTipoDoc == "5") { idValorReturn = "4"; }
    if (idTipoDoc == "2") { idValorReturn = "2"; }
   
    return idValorReturn;
}
function validarNumeroTelefonoFijo(numeroCel) {
    var numConError = false;

    if (numeroCel != null) {
        if (numeroCel.length < 7 || numeroCel.length > 9) {
            numConError = true;
        }

    } else {
        numConError = true;
    }
    return numConError;
}

function fn_VolverCargarPagina() {
    window.location.reload();
}


function validarDocIdentidad(e, opcion) {
    if (opcion == 1) {
        var idTipoDoc = $("#ddlTipoDocEntidad").val();
        if (idTipoDoc == "3" || idTipoDoc == "392") {
            var regex = new RegExp("^[0-9]+$");
            var cadena = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            if (!regex.test(cadena)) { event.preventDefault(); return false; } else { return true; }
        } else {
            var regex = new RegExp("^[a-zA-Z0-9]+$");
            var cadena = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            //var cadena = String.fromCharCode(key);
            if (!regex.test(cadena)) { event.preventDefault(); return false; } else { return true; }
        }
    } else if (opcion == 2) {
        var idTipoDoc = $("#ddlTipoDocEntidadBen").val();
        if (idTipoDoc == "3" || idTipoDoc == "392") {
            var regex = new RegExp("^[0-9]+$");
            var cadena = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            if (!regex.test(cadena)) { event.preventDefault(); return false; } else { return true; }
        } else {
            var regex = new RegExp("^[a-zA-Z0-9]+$");
            var cadena = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            //var cadena = String.fromCharCode(key);
            if (!regex.test(cadena)) { event.preventDefault(); return false; } else { return true; }
        }
    } else {

        return false;
    }
}

function validarEdaMinMaxPersona(fechaNacimiento) {
    var msj = "";
    var values = fechaNacimiento.split("/");
    var dia = values[0];
    var mes = values[1];
    var ano = values[2];

    // cogemos los valores actuales
    var fecha_hoy = new Date();
    var ahora_ano = fecha_hoy.getYear();
    var ahora_mes = fecha_hoy.getMonth() + 1;
    var ahora_dia = fecha_hoy.getDate();

    // realizamos el calculo
    var edad = (ahora_ano + 1900) - ano;
    if (ahora_mes < mes) {
        edad--;
    }
    if ((mes == ahora_mes) && (ahora_dia < dia)) {
        edad--;
    }
    if (edad > 1900) {
        edad -= 1900;
    }

    // calculamos los meses
    var meses = 0;
    if (ahora_mes > mes)
        meses = ahora_mes - mes;
    if (ahora_mes < mes)
        meses = 12 - (mes - ahora_mes);
    if (ahora_mes == mes && dia > ahora_dia)
        meses = 11;

    // calculamos los dias
    var dias = 0;
    if (ahora_dia > dia)
        dias = ahora_dia - dia;
    if (ahora_dia < dia) {
        ultimoDiaMes = new Date(ahora_ano, ahora_mes, 0);
        dias = ultimoDiaMes.getDate() - (dia - ahora_dia);
    }
    if (edad >= 120) {
        msj = "La fecha de nacimiento no cumple con la edad máxima";
    }
    if (edad == 0 && meses == 0 && dias <= 0) {
        msj = "La fecha de nacimiento no cumple con la edad mínima";
    }
    return msj;    
}

function validarCopyPasteValorNumerico(e) {
	var regex = new RegExp("^[0-9]+$"); var valor = e.originalEvent.clipboardData.getData('Text'); if (!regex.test(valor)) { e.preventDefault(); }
}
function validarCopyPasteValorAlfaNumerico(e) {
	var regex = new RegExp("^[a-zA-Z0-9]+$"); var valor = e.originalEvent.clipboardData.getData('Text'); if (!regex.test(valor)) { e.preventDefault(); }
}
function validarCopyPasteValorDescAlfaNumerico(e) {
	var regex = new RegExp("^[a-zA-Z ñóéíúá´ÑÓÉÍÚÁ 0-9]+$"); var valor = e.originalEvent.clipboardData.getData('Text'); if (!regex.test(valor)) { e.preventDefault(); }
}
function validarCopyPasteValorDescNombre(e) {
	var regex = new RegExp("^[a-zA-Z ñóéíúá´ÑÓÉÍÚÁ]+$"); var valor = e.originalEvent.clipboardData.getData('Text'); if (!regex.test(valor)) { e.preventDefault(); }
}
function validarCopyPasteValorDescComentario(e) {
    var regex = new RegExp("^[a-zA-Z ñóéíúáÑÓÉÍÚÁ 0-9- ._/,]+$"); var valor = e.originalEvent.clipboardData.getData('Text'); if (!regex.test(valor)) { e.preventDefault(); }
}

function DecryptAES(str) {
    var decrypt = CryptoJS.AES.decrypt(str, key, {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    var decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
    return decryptedStr;
}


function obtenerRangoVigencia(diasVigencia, opcion) {
    var fecActual = new Date();
    var fecRetorno = "";

    if (opcion == 1) {
        fecActual.setDate(fecActual.getDate() + parseInt(diasVigencia));
    } else {
        fecActual.setDate(fecActual.getDate() - parseInt(diasVigencia));
    }

    var anio = fecActual.getFullYear();
    var mes = fecActual.getMonth() + 1;
    var dia = fecActual.getDate();

    if (mes < 10) {
        mes = "0" + mes;
    }
    if (dia < 10) {
        dia = "0" + dia;
    }

    fecRetorno = mes + "/" + dia + "/" + anio
    return fecRetorno;
}


function isNullOrEmptyOrUndefined(value) {
    return value === null || value === "" || typeof value === 'undefined' || value === 0 || value === "0";
}