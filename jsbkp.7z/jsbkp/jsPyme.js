﻿var itemCuentaAsegurado = new Object();
var aliasAplicativo;

$(function myfunction() {

    aliasAplicativo = '/' + ($("#FolderApp").val() ? $("#FolderApp").val() + "/" : "");


    $(".contentInicial").css("display", "");
    $(".contentEmision").css("display", "none");

    var numVigFutura = $("#numVigFutura").val();
    var numVigRetroactiva = $("#numVigRetroactiva").val();
    var maxDate = obtenerRangoVigencia(numVigFutura, 1);
    var minDate = obtenerRangoVigencia(numVigRetroactiva, 2);

    $('.fechaSistema').datetimepicker({
        format: 'DD/MM/YYYY',
        showTodayButton: false,
        useCurrent: false,
        minDate: minDate,
        maxDate: maxDate
    });

    var fecha = new Date()
    fecha = sumarDias(fecha, -6570)

    $('.fechaSistemaNacimiento').datetimepicker({
        format: 'DD/MM/YYYY',
        showTodayButton: false,
        maxDate: fecha
    });

    // Configurar datetimepicker con la fecha actual  
    $('#txtFechaInicioVigencia').val(moment().format('DD/MM/YYYY'));

    $("#ddlCanal").change(function () {
        var idPadre = $(this).val();
        if (idPadre != "" && idPadre != "0") {
            obtenerTerritorio(idPadre);
        }
    });

    $("#btnEmitir").click(function () {
        var msg = validarDatosEmisionPyme();
        if (msg == "") {          
            swal({
                title: VJS_TITULO_ALERT,
                text: VJS_PREGUNTA_CONFIRMACION_EMITIR,
                type: "info",
                showCancelButton: true,
                cancelButtonText: "Cancelar",
                confirmButtonText: "Aceptar",
                closeOnConfirm: true,
                closeOnCancel: true
            },
                function (isConfirm) {
                    if (isConfirm) {
                        fn_FinalizarEmisionPoliza();
                    }
                });
        }
        else {
            mostrarMensaje(msg, 1, "");
        }
    });

    $("#chkReplicaDireccion").click(function () {
        var checkReplica = $('#chkReplicaDireccion').prop('checked');
        if (checkReplica) {
            debugger;
            $("#ddlDepartamentoRiesg").val($("#ddlDepartamento").val()).trigger("change");           
            setTimeout(() => { $('#ddlProvinciaRiesg').val($("#ddlProvincia").val()).trigger("change"); }, 500);
            setTimeout(() => { $('#ddlDistritoRiesg').val($("#ddlDistrito").val()).trigger("change"); }, 800);
            $("#ddlTipoViaRiesg").val($("#ddlTipoVia").val());
            $("#txtNombreViaRiesg").val($("#txtNombreVia").val());
            $("#ddlTipoNumeroRiesg").val($("#ddlTipoNumero").val());
            $("#txtNombreNumeroRiesg").val($("#txtNombreNumero").val());            
        }
    });

    $("#btnCancelar").click(function () {
        swal({
            title: VJS_TITULO_ALERT,
            text: VJS_PREGUNTA_CANCELAR,
            type: "info",
            showCancelButton: true,
            cancelButtonText: "Cancelar",
            confirmButtonText: "Aceptar",
            closeOnConfirm: true,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {
                    inicializarOfertas();                    
                    $(".contentEmision").css("display", "none");
                }
            });
    });

  

    // Detectar cambios en el input

    $("#ddlTipoMoneda").on("change", function () {
        var initialValue = itemCuentaAsegurado.idTipoMoneda;
        var currentValue = $(this).val();
        if (currentValue !== initialValue) {
            inicializarOfertas();
        }
    });



    $("#ddlTipoMaterialEdif").on("change", function () {
        var valorMaterial = $(this).val();
        // Valores específicos para mostrar el mensaje
        var valoresNoAsegurables = ["645", "649", "665", "668", "670"];

        // Verificar si el valor seleccionado está en la lista de valores no asegurables
        if (valoresNoAsegurables.includes(valorMaterial)) {
            mostrarMensaje("Riesgo no asegurable", 1, "");            
            $(this).val($("#ddlTipoMaterialEdif option:first").val()); // Inicializar el combo box (opcional: puedes establecerlo en un valor específico si es necesario)
        }
    });

    $("#ddlTipoUsoEdif").on("change", function () {
        var valorMaterial = $(this).val();
        // Valores específicos para mostrar el mensaje
        var valoresNoAsegurables = ["702", "704", "706"];        
        // Verificar si el valor seleccionado está en la lista de valores no asegurables
        if (valoresNoAsegurables.includes(valorMaterial)) {
            mostrarMensaje("Riesgo no asegurable", 1, "");
            $(this).val($("#ddlTipoUsoEdif option:first").val()); // Inicializar el combo box (opcional: puedes establecerlo en un valor específico si es necesario)
        }
    });
    $("#txtSumaAsegurada").on("change", function () {
        var initialValue = itemCuentaAsegurado.sumaAsegurada;
        var currentValue = $(this).val();      

        if (currentValue !== initialValue) {
            inicializarOfertas();
        }
    });
    $("#txtFechaInicioVigencia").on("change", function () {
        var initialValue = itemCuentaAsegurado.fechaInicioVigencia;
        var currentValue = $(this).val();
        if (currentValue !== initialValue) {
            inicializarOfertas();
        }
    });

    $("#ddlTipoMedioPago").on("change", function () {
        var initialValue = itemCuentaAsegurado.idTipoMedioPago;
        var currentValue = $(this).val();
        if (currentValue !== initialValue) {
            inicializarOfertas();
        }
    });

    $("#ddlTipoPago").on("change", function () {
        var initialValue = itemCuentaAsegurado.idTipoPago;
        var currentValue = $(this).val();
        if (currentValue !== initialValue) {
            inicializarOfertas();
        }
    });

    $("#ddlTerritorio").change(function () {
        var idPadre = $(this).val();
        if (idPadre != "" && idPadre != "0") {
            obtenerZona(idPadre);
        }
    });

    $("#ddlZona").change(function () {
        var idPadre = $(this).val();
        if (idPadre != "" && idPadre != "0") {
            obtenerRegion(idPadre);
        }
    });

    $("#ddlRegion").change(function () {
        var idPadre = $(this).val();
        if (idPadre != "" && idPadre != "0") {
            obtenerPuntoVenta(idPadre);
        }
    });

    $("#ddlPuntoVenta").change(function () {
        var idPadre = $(this).val();
        if (idPadre != "" && idPadre != "0") {
            obtenerVendedor(idPadre);
        }
    });

    $("#txtSumaAsegurada").change(function () {
        var valor = $(this).val();
        $(this).val(devolverNumero(valor, 2));
    });

    $("#ddlTipoDocEntidad").change(function () {
        var idTipoDoc = $(this).val();
        if (idTipoDoc != "") {
            for (var i in listadoDocIdentidad.items) {
                if (listadoDocIdentidad.items[i].value === idTipoDoc) {
                    $("#txtNumeroDocIdentidad").prop("maxlength", listadoDocIdentidad.items[i].lon);
                    break;
                }
            }
            if (idTipoDoc == ID_TIPO_IDENTIDAD_RUC) { // RUC
                $(".personaNatural").css("display", "none");
                $("#txtPrimerNombre").attr("placeholder", "RAZON SOCIAL (*)");
                $("#txtNumeroDocIdentidad").attr("placeholder", "RUC (*)");

            } else { // RUC
                $(".personaNatural").css("display", "");
                $("#txtPrimerNombre").attr("placeholder", "PRIMER NOMBRE (*)");
                $("#txtNumeroDocIdentidad").attr("placeholder", "NRO. DOCUMENTO (*)");
            }

        }
    });

    /*BUSCAR ASEGURADO (DNI)*/
    $('#txtNumeroDocIdentidad').change(() => {
        let tDocumentoidentidad = $('#ddlTipoDocEntidad').val();
        if (tDocumentoidentidad !== '') {
            if ($('#txtNumeroDocIdentidad').val().length > 4) {
                let documentoIdentidad = $('#txtNumeroDocIdentidad').val();
                obtenerInformacionASegurado(tDocumentoidentidad, documentoIdentidad);
            } else {
                mostrarMensaje("Número de documento Inválido o vacío.", 1, "");
            }
        } else {
            mostrarMensaje("Seleccione el tipo documento.", 1, "");
        }

    });

    /*SELECT'S ASEGURADO*/
    $('#ddlDepartamento').change(() => {
        let idDepartamento = $('#ddlDepartamento').val();
        if (idDepartamento !== '' && idDepartamento !== '0') {
            obtenerProvincia(idDepartamento, '', 'ddlProvincia');
        } else {
            $('#ddlProvincia').html("");
            $('#ddlProvincia').append($("<option></option>").val("").html("SELECCIONE LA PROVINCIA (*)"));
        }

        $('#ddlDistrito').html("");
        $('#ddlDistrito').append($("<option></option>").val("").html("SELECCIONE EL DISTRITO (*)"));
    });

    $('#ddlProvincia').change(() => {
        let idProvincia = $('#ddlProvincia').val();
        if (idProvincia !== '' && idProvincia !== '0') {
            obtenerDistrito(idProvincia, '', 'ddlDistrito');
        } else {
            $('#ddlDistrito').html("");
            $('#ddlDistrito').append($("<option></option>").val("").html("SELECCIONE EL DISTRITO (*)"));
        }
    });

    /*SELECT'S  RIESGOS*/
    $('#ddlDepartamentoRiesg').change(() => {
        let idDepartamento = $('#ddlDepartamentoRiesg').val();
        if (idDepartamento !== '' && idDepartamento !== '0') {
            obtenerProvincia(idDepartamento, '', 'ddlProvinciaRiesg');
        } else {
            $('#ddlProvinciaRiesg').html("");
            $('#ddlProvinciaRiesg').append($("<option></option>").val("").html("SELECCIONE LA PROVINCIA (*)"));
        }

        $('#ddlDistritoRiesg').html("");
        $('#ddlDistritoRiesg').append($("<option></option>").val("").html("SELECCIONE EL DISTRITO (*)"));
    });

    $('#ddlProvinciaRiesg').change(() => {
        debugger;
        let idProvincia = $('#ddlProvinciaRiesg').val();
        if (idProvincia !== '' && idProvincia !== '0') {
            obtenerDistrito(idProvincia, '', 'ddlDistritoRiesg');
        } else {
            $('#ddlDistritoRiesg').html("");
            $('#ddlDistritoRiesg').append($("<option></option>").val("").html("SELECCIONE EL DISTRITO (*)"));
        }
    });
    /*btnEmitir*/
    cargarEstructuraComercial();

    $("#ddlTipoMedioPago").val(707);
    $("#ddlTipoPago").val(91);
});

function cargarEstructuraComercial() {
    Bloquear();

    $.ajax({
        cache: false,
        type: "GET",
        url: aliasAplicativo + "Estructura/EstructuraComercial",
        success: function (data) {
            var idCanal = data[0].idCanal;
            var idTerritorio = data[0].idTerritorio;
            var idZona = data[0].idZona;
            var idRegion = data[0].idRegion;
            var idPtoVenta = data[0].idPtoVenta;
            var idPersona = data[0].idPersona;

            if (idPersona != 0) {
                $("#ddlCanal").val(idCanal);
                $("#ddlTerritorio").val(idTerritorio);
                $("#ddlZona").val(idZona);
                $("#ddlRegion").val(idRegion);
                $("#ddlPuntoVenta").val(idPtoVenta);
                $("#ddlVendedor").val(idPersona);
            }
            Desbloquear();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        }
    });
}
function inicializarOfertas() {
    var tabla = "<table class='tabla_cotizacion'><thead><tr>";
    tabla += "<th class='borde_top' colspan='8'></th></tr>";

    tabla += "<tr><th class='seleccionarPlan columna-seleccion'></th>";
    tabla += "<th class='tituloOfertas columna-compania' style='width: 40%;' >Compañía</th>";
    tabla += "<th class='tituloOfertas columna-plan' >Plan</th>";
    tabla += "<th class='tituloOfertas columna-cuotatotal' >Prima Total</th>"
    tabla += "<th class='tituloOfertas columna-opcion' colspan='2'>Opciones</th></tr></thead>";
    $(".divPlanesEncontrados").html("<label class='planesEncontrados'>No se encontraron planes o no se realizó una búsqueda</label>");
    var registros = "<tbody><tr class='odd'><td valign='top' colspan='7' class='dataTables_empty'>No hay planes disponibles</td></tr></tbody>";
    tabla = tabla + registros + ' </table>'
    $("#divResultadoCotizacion").html("");
    $("#divResultadoCotizacion").html(tabla);

    itemCuentaAsegurado.idTarifaBase = 0;
    itemCuentaAsegurado.idPlanEmision = 0;
    itemCuentaAsegurado.primaNeta = 0;
    itemCuentaAsegurado.primaBruta = 0;
    itemCuentaAsegurado.impuestos = 0;   
    itemCuentaAsegurado.idPersonaVendedor = 0;
    $(".contentEmision").css("display", "none");
}


//GENERAR OFERTA DE PLANES    
function buscarOfertasPlanes() {

    var msg = validarDatosPyme();

    if (msg == "") {
        var registros = "";

        var cuotMensual;

        var tabla = "<table class='tabla_cotizacion'><thead><tr>";
        tabla += "<th class='borde_top' colspan='8'></th></tr>";

        tabla += "<tr><th class='seleccionarPlan columna-seleccion'></th>";
        tabla += "<th class='tituloOfertas columna-compania' style='width: 40%;' >Compañía</th>";
        tabla += "<th class='tituloOfertas columna-plan' >Plan</th>";
        tabla += "<th class='tituloOfertas columna-cuotatotal' >Prima Total</th>"
        tabla += "<th class='tituloOfertas columna-opcion' colspan='2'>Opciones</th></tr></thead>";

        totalRegistrosEncontrados = 0;

        var valorDec = $("#txtSumaAsegurada").val().replaceAll(",", "");

        itemCuentaAsegurado.idPuntoVenta = $("#ddlPuntoVenta").val();
        itemCuentaAsegurado.idPersonaVendedor = $("#ddlVendedor").val();
        itemCuentaAsegurado.idTipoMoneda = $("#ddlTipoMoneda").val();
        itemCuentaAsegurado.sumaAsegurada = valorDec;
        itemCuentaAsegurado.nroCuotas = 1;
        itemCuentaAsegurado.fechaInicioVigencia = $("#txtFechaInicioVigencia").val();
        itemCuentaAsegurado.idTipoMedioPago = $('#ddlTipoMedioPago').val();
        itemCuentaAsegurado.idTipoPago = $('#ddlTipoPago').val();



        var opcion = 1;

        if (opcion === 1) {
            var result;
            var parametros = `{objCotizacion : ${JSON.stringify(itemCuentaAsegurado)}}`
            $.ajax({
                cache: false,
                type: "POST",
                timeout: 600000,
                url: aliasAplicativo + "Seguro/CotizarPlanPyme",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: parametros,
                cache: false,
                success: (data) => {
                    result = data;

                    if (result.state) {
                        $.each(result.listaOfertas, function (id, option) {

                            totalRegistrosEncontrados++;
                            cuotMensual = devolverNumerosincoma(option.primBr, 2);
                            if (typeof cuotMensual == "undefined") {
                                cuotMensual = devolverNumero(0, 2);
                            }
                            registros += '<tr>';
                            registros += "<td class='seleccionarPlan'>";
                            registros += "</td>";

                            if (option.logo != null) {
                                if (option.logo.split('/').pop() != null && option.logo.split('/').pop() != "") {
                                    registros += "<td class='text-left'><img src= '" + option.logo + "' alt='Image' style='overflow: hidden; position: relative; width:50%;'/></td>";
                                } else {
                                    registros += "<td class='text-left'>" + option.nomEnti + "</td>";
                                }
                            } else {
                                registros += "<td class='text-left'>" + option.nomEnti + "</td>";
                            }
                            registros += "<td class='dato-compania'>" + option.nomOfer + "</td>";
                            registros += "<td class='dato-cuota-mensual' >" + option.moneda + "  " + devolverNumero(cuotMensual, 2) + "</td>";
                            registros += "<td class='celdaAccion text-right'>";

                            if (parseFloat(option.pNet) > 0) {
                                registros += "<a href='JavaScript:cargarDetalleCSD(" + option.idPla + ")' class='fa fa-info-circle fa-2x infoComponentes' style='margin-right: 16px;' title='Ver beneficios, coberturas y deducibles' ></a>";
                            }
                            registros += "</td>";
                            registros += '<td class="columna-emitir">';
                            if (parseFloat(option.pNet) > 0) {
                                registros += '<button class="boton-emitir" title = "Emitir Póliza" type="button" onclick="fn_emitirPoliza(' + option.idTarifa + ',' + option.idPla + ',' + option.pNet + ',' + option.primBr + ',' + option.imp + ',' + option.pDe + ',' + "'" + option.nomOfer + "'" + ',' + "'" + option.nomProd + "'," + "'" + option.moneda + "'," + "'" + option.nomEnti + "'," + option.indObs + ",'" + option.obs + "'" + ')"><i class="fa fa-check-square-o"></i></button > ';
                            }
                            registros += '</td>';
                            registros = registros + '</tr>';
                        });
                    }
                },
                error: (error) => {
                    console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                    $(".divPlanesEncontrados").html("<label class='planesEncontrados'>No se encontraron planes o no se realizó una búsqueda</label>");
                    registros = "<tbody><tr class='odd'><td valign='top' colspan='7' class='dataTables_empty'>No hay planes disponibles</td></tr></tbody>";
                    tabla = tabla + registros + ' </table>'
                    $("#divResultadoCotizacion").html("");
                    $("#divResultadoCotizacion").html(tabla);
                    mostrarMensaje(VJS_MSG_ERROR, 1, "");
                    Desbloquear();
                },
                complete: function (xhr, status) {
                    if (result.state) {
                        if (totalRegistrosEncontrados > 0) {
                            tabla = tabla + registros + ' </table>';
                            $("#divResultadoCotizacion").html("");
                            $("#divResultadoCotizacion").html(tabla);
                            var mensajePopupFinal = "";
                            if (totalRegistrosEncontrados == 1) {
                                $(".divPlanesEncontrados").html("<label class='planesEncontrados'>¡Planes encontrados! " + totalRegistrosEncontrados + " plan a la medida encontrado</label>");
                                mensajePopupFinal = "1 plan encontrado a medida de la información brindada ";
                            } else {
                                $(".divPlanesEncontrados").html("<label class='planesEncontrados'>¡Planes encontrados! " + totalRegistrosEncontrados + " planes a la medida encontrados</label>");
                                mensajePopupFinal = totalRegistrosEncontrados.toString() + " planes encontrados a medida de la información brindada ";
                            }
                            if (totalRegistrosEncontrados > 0) {
                                $(".seleccionarPlan").show();
                            } else {
                                $(".seleccionarPlan").hide();
                            }
                            swal({
                                title: "Planes Encontrados ",
                                text: mensajePopupFinal,
                                type: "success",
                                showCancelButton: false,
                                closeOnConfirm: false,
                                closeOnConfirm: true
                            }, function () {
                            });
                        } else {
                            $(".divPlanesEncontrados").html("<label class='planesEncontrados'>No se encontraron planes o no se realizó una búsqueda</label>");
                            registros = "<tbody><tr class='odd'><td colspan='7' >No hay planes disponibles</td></tr></tbody>";
                            tabla = tabla + registros + ' </table>'
                            $("#divResultadoCotizacion").html("");
                            $("#divResultadoCotizacion").html(tabla);
                            swal({
                                title: "Sin Información",
                                text: "No se encontraron planes a medida de la información brindada",
                                type: "info",
                                showCancelButton: false,
                                closeOnConfirm: false,
                                closeOnConfirm: true
                            }, function () {
                            });
                        }
                    } else {
                        $.each(result.property, function (index, propertyName) {
                            $("#" + propertyName).addClass("valorObligatorio");
                        });
                        mostrarMensaje(result.message, 1, "");
                    }
                    Desbloquear();
                }
            });
        }
    } else {
        mostrarMensaje(msg, 1, "");
    }
}

function obtenerInformacionASegurado(idTipoDocumento, documentoIdentidad) {
    Bloquear();
    $.ajax({
        cache: false,
        type: 'GET',
        url: `${aliasAplicativo}Seguro/ObtenerInformacionAsegurado`,
        data: {
            'idTipoDocumento': idTipoDocumento,
            'documentoIdentidad': documentoIdentidad
        },
        success: (data) => {
            if (data.id == 0) {
                mostrarMensaje(data.mensaje, 1, "");
                //console.log(JSON.stringify(data));
            } else {
                if (data.idTercero > 0) {
                    if (data.tipoIdentidad.idTipo !== parseInt(ID_TIPO_IDENTIDAD_RUC)) {
                        $('#txtApellidoPaterno').val(data.apePaterno);
                        $('#txtApellidoMaterno').val(data.apeMaterno);
                        $('#txtPrimerNombre').val(data.primerNombre);
                        $('#txtSegundoNombre').val(data.segundoNombre);
                        $('#txtFechaNacimiento').val(data.fecNacimiento);
                        if (data.idEstadoCivil != 0)
                            $('#ddlTipoEstadoCivil').val(data.idEstadoCivil);
                        if (data.idTipoGenero != 0)
                            $('#ddlTipoGenero').val(data.idTipoGenero);
                    } else {
                        $('#txtPrimerNombre').val(data.nombre);
                    }

                    if (data.idActividad != 0)
                        $('#ddlActividadEconomica').val(data.idActividad);

                    $('#txtCelular').val(data.celular);
                    $("#txtTelefono").val(data.telefono);
                    $('#txtCorreo').val(data.correo);
                    $('#txtDireccion').val(data.direccion);

                    if (data.departamento.idUbigeo != 0) {
                        $('#ddlDepartamento').val(data.departamento.idUbigeo).trigger("change");
                        if (data.provincia.idUbigeo != 0) {
                            setTimeout(() => { $('#ddlProvincia').val(data.provincia.idUbigeo).trigger("change"); }, 500);
                            if (data.distrito.idUbigeo != 0) {
                                setTimeout(() => { $('#ddlDistrito').val(data.distrito.idUbigeo).trigger("change"); }, 800);
                            }
                        }
                    }

                    if (data.tipoVia.idTipo != 0)
                        $('#ddlTipoVia').val(data.tipoVia.idTipo);

                    $('#txtNombreVia').val(data.numeroVia);

                    if (data.idTipoInterior != 0)
                        $('#ddlTipoInterior').val(data.idTipoInterior);

                    $('#txtInterior').val(data.interior);

                    if (data.idTipoUrbanizacion != 0)
                        $('#ddlTipoUrbanizacion').val(data.idTipoUrbanizacion);

                    $('#txtNombreUrbanizacion').val(data.nombreUrbanizacion);

                    if (data.idTipoNumero != 0)
                        $('#ddlTipoNumero').val(data.idTipoNumero);

                    $('#txtNombreNumero').val(data.nombreNumero);
                }
            }
            
        },
        error: (jqXHR, textStatus, errorThrown) => {
            mostrarMensaje("No se encontró el asegurado.", 1, "");
            Desbloquear();
        },
        complete: (xhr, status) => {
            Desbloquear();
        }
    });
}

function obtenerProvincia(idDepartamento, idProvincia, idSelected) {
    Bloquear();
    let selected = $(`#${idSelected}`);

    $.ajax({
        cache: false,
        type: 'GET',
        url: `${aliasAplicativo}General/ObtenerProvincia`,
        data: { 'idUbigeo': idDepartamento },
        success: (data) => {
            selected.html("");
            selected.append($("<option></option>").val("").html("SELECCIONE LA PROVINCIA(*)"));

            $.each(data, (index, item) => { selected.append($(`<option></option>`).val(item.id).html(item.name)); });

            if (data.length === 0) selected.append($(`<option></option>`).val("").html("SIN REGISTROS"));

            if (idProvincia != null && idProvincia != "" && idProvincia != "0") selected.val(idProvincia);
        },
        error: (jqXHR, textStatus, errorThrown) => {
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: (xhr, status) => {
            Desbloquear();
        }
    });


}

function obtenerDistrito(idProvincia, idDistrito, idSelected) {
    Bloquear();
    let selected = $(`#${idSelected}`);

    $.ajax({
        cache: false,
        type: 'GET',
        url: `${aliasAplicativo}General/ObtenerDistrito`,
        data: { 'idUbigeo': idProvincia },
        success: (data) => {
            selected.html("");
            selected.append($("<option></option>").val("").html("SELECCIONE EL DISTRITO (*)"));

            $.each(data, (index, item) => { selected.append($(`<option></option>`).val(item.id).html(item.name)); });

            if (data.length === 0) selected.append($(`<option></option>`).val("").html("SIN REGISTROS"));

            if (idDistrito != null && idDistrito != "" && idDistrito != "0") selected.val(idProvincia);
        },
        error: (jqXHR, textStatus, errorThrown) => {
            //console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: (xhr, status) => {
            Desbloquear();
        }
    });
}

function cargarDetalleCSD(idPlan) {
    Bloquear();

    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Cotizacion/ObtenerDatosPlan',
        data: { "id": idPlan },
        cache: false,
        success: function (data) {
            if (data.id == 0) {
                console.log(JSON.stringify(data));
            } else {
                $.ajax({
                    type: 'GET',
                    url: aliasAplicativo + 'Cotizacion/PlanCoberturaCotizacion',
                    contentType: "application/json; charset=utf-8",
                    dataType: "html",
                    data: { "id": idPlan },
                    cache: false,
                    success: function (data) {
                        $("#myModal #grilla_cobertura").html("");
                        $("#myModal #grilla_cobertura").html(data);

                        $.ajax({
                            type: 'GET',
                            url: aliasAplicativo + 'Cotizacion/PlanServicioCotizacion',
                            contentType: "application/json; charset=utf-8",
                            dataType: "html",
                            data: { "id": idPlan },
                            cache: false,
                            success: function (data) {
                                $("#myModal #grilla_servicio").html("");
                                $("#myModal #grilla_servicio").html(data);

                                $.ajax({
                                    type: 'GET',
                                    url: aliasAplicativo + 'Cotizacion/PlanDeducibleCotizacion',
                                    contentType: "application/json; charset=utf-8",
                                    dataType: "html",
                                    data: { "id": idPlan },
                                    cache: false,
                                    success: function (data) {
                                        $("#myModal #grilla_deducible").html("");
                                        $("#myModal #grilla_deducible").html(data);
                                    },
                                    error: function (jqXHR, textStatus, errorThrown) {
                                        console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                                        mostrarMensaje(VJS_MSG_ERROR, 1, "");
                                        Desbloquear();
                                    },
                                    complete: function () {
                                        $("#myModal #txtCompania").html($("#grilla_cobertura #nomEntidad").val());
                                        $("#myModal #txtProducto").html($("#grilla_cobertura #desProducto").val());
                                        $("#myModal #txtPlan").html($("#grilla_cobertura #desCortaPlan").val());
                                        Desbloquear();
                                        $('#myModal').modal('show');
                                    }
                                });
                            },
                            error: function (jqXHR, textStatus, errorThrown) {
                                console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                                mostrarMensaje(VJS_MSG_ERROR, 1, "");
                                Desbloquear();
                            },
                        });
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
                        mostrarMensaje(VJS_MSG_ERROR, 1, "");
                        Desbloquear();
                    },
                });
            }
            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
    });
}

function validarDatosPyme() {
    var mensaje = "";

    var idCanal = $("#ddlCanal").val();
    if (idCanal === "") {
        $("#ddlCanal").addClass("valorObligatorio");
        mensaje += "* Seleccione el canal.";
        mensaje += "<br/>";
    } else { $("#ddlCanal").removeClass("valorObligatorio"); }

    var idTerritorio = $("#ddlTerritorio").val();
    if (idTerritorio === "") {
        $("#ddlTerritorio").addClass("valorObligatorio");
        mensaje += "* Seleccione el territorio.";
        mensaje += "<br/>";
    } else { $("#ddlTerritorio").removeClass("valorObligatorio"); }

    var idZona = $("#ddlZona").val();
    if (idZona === "") {
        $("#ddlZona").addClass("valorObligatorio");
        mensaje += "* Seleccione la zona.";
        mensaje += "<br/>";
    } else { $("#ddlZona").removeClass("valorObligatorio"); }

    var idRegion = $("#ddlRegion").val();
    if (idRegion === "") {
        $("#ddlRegion").addClass("valorObligatorio");
        mensaje += "* Seleccione la región.";
        mensaje += "<br/>";
    } else { $("#ddlRegion").removeClass("valorObligatorio"); }

    var idPtoVenta = $("#ddlPuntoVenta").val();
    if (idPtoVenta === "") {
        $("#ddlPuntoVenta").addClass("valorObligatorio");
        mensaje += "* Seleccione el punto de venta.";
        mensaje += "<br/>";
    } else { $("#ddlPuntoVenta").removeClass("valorObligatorio"); }

    var idVendedor = $("#ddlVendedor").val();
    if (idVendedor === "") {
        $("#ddlVendedor").addClass("valorObligatorio");
        mensaje += "* Seleccione el vendedor.";
        mensaje += "<br/>";
    } else { $("#ddlVendedor").removeClass("valorObligatorio"); }

    var idMoneda = $("#ddlTipoMoneda").val();
    if (isNullOrEmptyOrUndefined(idMoneda)) {
        $("#ddlTipoMoneda").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de moneda.";
        mensaje += "<br/>";
    } else { $("#ddlTipoMoneda").removeClass("valorObligatorio"); }

    if ($("#txtSumaAsegurada").val() == "") {
        $("#txtSumaAsegurada").addClass("valorObligatorio");
        mensaje += "* Ingrese la suma asegurada.";
        mensaje += "<br/>";
    } else {
        var valorDec = $("#txtSumaAsegurada").val().replaceAll(",", "");
        if ((idMoneda == 219) && (parseInt(valorDec) > 300000)) {
            $("#txtSumaAsegurada").addClass("valorObligatorio");
            mensaje += "* El valor ingresado a superado lo permitido.";
            mensaje += "<br/>";
        } else {
            if ((parseInt(idMoneda) == 220) && (parseFloat(valorDec) > 300000)) {
                $("#txtSumaAsegurada").addClass("valorObligatorio");
                mensaje += "* El valor ingresado a superado lo permitido.";
                mensaje += "<br/>";
            } else {
                $("#txtSumaAsegurada").removeClass("valorObligatorio");
            }
        }
    }

    var tipoValor = $("#ddlTipoMedioPago").val();
    if (isNullOrEmptyOrUndefined(tipoValor)) {
        $("#ddlTipoMedioPago").addClass("valorObligatorio");
        mensaje += "* Seleccione el medio de pago.";
        mensaje += "<br/>";
    } else { $("#ddlTipoMedioPago").removeClass("valorObligatorio"); }

    var ddlTipoFormaPago = $("#ddlTipoPago").val();
    if (isNullOrEmptyOrUndefined(ddlTipoFormaPago)) {
        $("#ddlTipoPago").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de pago.";
        mensaje += "<br/>";
    } else { $("#ddlTipoPago").removeClass("valorObligatorio"); }

    return mensaje;
}

function fn_emitirPoliza(idTarifa, idPl, primN, priBrut, mImp, monDe, nomPlan, nomProd) {

    var msg_ini = validarDatosPyme();

    if (msg_ini == "") {     
        itemCuentaAsegurado.idTarifaBase = idTarifa;
        itemCuentaAsegurado.idPlanEmision = idPl;
        itemCuentaAsegurado.primaNeta = primN;
        itemCuentaAsegurado.primaBruta = priBrut;
        itemCuentaAsegurado.impuestos = mImp;
        itemCuentaAsegurado.derechoEmision = monDe;
        itemCuentaAsegurado.nomPlan = nomPlan;
        itemCuentaAsegurado.nomProducto = nomProd;
        itemCuentaAsegurado.idPersonaVendedor = $("#ddlVendedor").val();

        var msg = '¿Está seguro de seleccionar la oferta?';
        swal({
            title: VJS_TITULO_ALERT,
            text: msg,
            type: "info",
            showCancelButton: true,
            cancelButtonText: "Cancelar",
            confirmButtonText: "Aceptar",
            confirmButtonClass: "botonAceptarCotizar",
            closeOnConfirm: true,
            closeOnCancel: true
        },
            function (isConfirm) {
                if (isConfirm) {                    
                    $(".contentEmision").css("display", "");
                    if ($("#ddlTipoMoneda").val() === "219") {
                        $("#txtSumaAseguradaEdif").val("S/" + devolverNumero(itemCuentaAsegurado.sumaAsegurada, 2));
                    } else {
                        $("#txtSumaAseguradaEdif").val("$" + devolverNumero(itemCuentaAsegurado.sumaAsegurada,2));
                    }

                }
            });
    } else {
        mostrarMensaje(msg_ini, 1, "");
    }
}

function fn_FinalizarEmisionPoliza() {
    // Asignación de valores desde elementos HTML a propiedades del objeto
    itemCuentaAsegurado.idTipoDocumento = $("#ddlTipoDocEntidad").val();
    itemCuentaAsegurado.nroDocIdentidad = $("#txtNumeroDocIdentidad").val();
    itemCuentaAsegurado.apellidoPaterno = $("#txtApellidoPaterno").val();
    itemCuentaAsegurado.apellidoMaterno = $("#txtApellidoMaterno").val();
    itemCuentaAsegurado.primerNombre = $("#txtPrimerNombre").val();
    itemCuentaAsegurado.segundoNombre = $("#txtSegundoNombre").val();
    itemCuentaAsegurado.fechaNacimiento = $("#txtFechaNacimiento").val(); // Asumiendo que el valor es una fecha válida
    itemCuentaAsegurado.idTipoGenero = $("#ddlTipoGenero").val();
    itemCuentaAsegurado.idTipoEstadoCivil = $("#ddlTipoEstadoCivil").val();
    itemCuentaAsegurado.idActividadEconomica = $("#ddlActividadEconomica").val();

    itemCuentaAsegurado.correoElectronico = $("#txtCorreo").val();
    itemCuentaAsegurado.telefono = $("#txtTelefono").val();
    itemCuentaAsegurado.celular = $("#txtCelular").val();

    itemCuentaAsegurado.idDepartamento = $("#ddlDepartamento").val();
    itemCuentaAsegurado.idProvincia = $("#ddlProvincia").val();
    itemCuentaAsegurado.idDistrito = $("#ddlDistrito").val();
    itemCuentaAsegurado.idTipoVia = $("#ddlTipoVia").val();
    itemCuentaAsegurado.nombreVia = $("#txtNombreVia").val();
    itemCuentaAsegurado.idTipoNumero = $("#ddlTipoNumero").val();
    itemCuentaAsegurado.nombreNumero = $("#txtNombreNumero").val();


    itemCuentaAsegurado.idTipoInterior = $("#ddlTipoInterior").val();
    itemCuentaAsegurado.interior = $("#txtInterior").val();
    itemCuentaAsegurado.idTipoUrbanizacion = $("#ddlTipoUrbanizacion").val();
    itemCuentaAsegurado.nombreUrbanizacion = $("#txtNombreUrbanizacion").val();
    itemCuentaAsegurado.direccion = $("#txtDireccion").val();

    itemCuentaAsegurado.idDepartamentoRiesgo = $("#ddlDepartamentoRiesg").val();
    itemCuentaAsegurado.idProvinciaRiesgo = $("#ddlProvinciaRiesg").val();
    itemCuentaAsegurado.idDistritoRiesgo = $("#ddlDistritoRiesg").val();
    itemCuentaAsegurado.idTipoViaRiesgo = $("#ddlTipoViaRiesg").val();
    itemCuentaAsegurado.nombreViaRiesgo = $("#txtNombreViaRiesg").val();
    itemCuentaAsegurado.idTipoNumeroRiesgo = $("#ddlTipoNumeroRiesg").val();
    itemCuentaAsegurado.nombreNumeroRiesgo = $("#txtNombreNumeroRiesg").val();
    itemCuentaAsegurado.anioConst = $("#txtAnioConst").val(); // Asumiendo que el valor es un número válido
    itemCuentaAsegurado.idTipoUsoEdif = $("#ddlTipoUsoEdif").val();
    itemCuentaAsegurado.idTipoMaterialEdif = $("#ddlTipoMaterialEdif").val();
    itemCuentaAsegurado.pisosEdif = $("#txtPisosEdif").val(); // Asumiendo que el valor es un número válido
    itemCuentaAsegurado.sotanosEdif = $("#txtSotanosEdif").val(); // Asumiendo que el valor es un número válido
    itemCuentaAsegurado.direccionRiesgo = $("#txtDireccionRiesgo").val();
    itemCuentaAsegurado.sumaAseguradaRiesgo = itemCuentaAsegurado.sumaAsegurada; // Asumiendo que el valor es un número válido  
    itemCuentaAsegurado.bienesPropios = $("#txtBienesPropios").val(); // Asumiendo que el valor es un número válido
    itemCuentaAsegurado.existenciaPropias = $("#txtExistenciaPropias").val();

    var parametros = "{'objCotizacion': " + JSON.stringify(itemCuentaAsegurado) + " }";
    $.ajax({
        cache: false,
        type: "POST",
        timeout: 600000,
        url: aliasAplicativo + "Seguro/EmitirPolizaPyme",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: parametros,
        cache: false,
        success: function (data) {
            if (typeof data.id == "undefined") {
                $.each(data.property, function (index, propertyName) {
                    $("#" + propertyName).addClass("valorObligatorio");
                });
                setTimeout(function () {
                    swal({
                        title: "Mensaje Validación",
                        html: true,
                        text: data.mensaje,
                        type: "warning",
                        showCancelButton: false,
                        confirmButtonColor: "#0f9cd6",
                        confirmButtonText: "Aceptar",
                        closeOnConfirm: false
                    });
                }, 100);
            }
            else if (data.id > 0) {
                mostrarPolizaEmitida(data.idCertificado);
                setTimeout(function () {
                    mostrarMensaje(data.mensaje, 2, "");
                }, 100);
            }
            else {
                mostrarMensaje(data.mensaje, 1, "");
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
        }, complete: function () {
            Desbloquear();
        }
    });
}

function mostrarPolizaEmitida(idCertificado) {
    var iframe = document.getElementById("iFramePoliza");
    var html = "";
    $("#tituloModalImprimir").html("Datos Generales del Certificado ");
    iframe.contentWindow.document.open();
    iframe.contentWindow.document.write(html);
    iframe.contentWindow.document.close();
    $("#iFramePoliza").attr("src", aliasAplicativo + "Emision/AbrirDetallePolizaEmitida?id=" + idCertificado);
    $("#modalEmitido").modal();
}

function CerrarIframe() {
    Bloquear();
    window.location.href = aliasAplicativo + "Seguro/Pyme";
}

function sumarDias(fecha, dias) {
    fecha.setDate(fecha.getDate() + dias);
    return fecha;
}

function descargarReporteSSRS(idCertificado, nombreReporte) {
    $("#frmDescarga #idCertificadoTemp").val(idCertificado);
    $("#frmDescarga #tipoReporte").val(nombreReporte);
    var formulario = "";

    formulario = $("#frmDescarga").serialize();
    var valor = 0;

    Bloquear();
    $.ajax({
        type: 'POST',
        url: aliasAplicativo + 'Reporte/DescargarCertificadoSSRS',
        data: formulario,
        cache: false,
        success: function (data) {
            valor = data.id;
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log("error: " + errorThrown + " status: " + textStatus + " er:" + jqXHR.responseText);
            mostrarMensaje(VJS_MSG_ERROR, 1, "");
            Desbloquear();
        },
        complete: function () {
            if (valor === 1) {
                window.location = aliasAplicativo + 'DocumentoDescargas/DescargarReporteCertificadoGenerado';
            } else {
                mostrarMensaje(VJS_MSG_ERROR, 1, "");
            }
            Desbloquear();
        }
    });
}


function validarDatosEmisionPyme() {
    var mensaje = "";

    var idTipoDocIdentidad = $("#ddlTipoDocEntidad").val();

    if (isNullOrEmptyOrUndefined(idTipoDocIdentidad)) {
        $("#ddlTipoDocEntidad").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de documento.";
        mensaje += "<br/>";
    } else { $("#ddlTipoDocEntidad").removeClass("valorObligatorio"); }

    var numeroDoc = $("#txtNumeroDocIdentidad").val();
    if (numeroDoc == "") {
        $("#txtNumeroDocIdentidad").addClass("valorObligatorio");
        mensaje += "* Ingrese el número de documento de Identidad.";
        mensaje += "<br/>";
    } else {
        numConError = validarTipoDocumento(idTipoDocIdentidad, numeroDoc);
        if (numConError) {
            $("#txtNumeroDocIdentidad").addClass("valorObligatorio");
            mensaje += "* El número documento es inválido";
            mensaje += "<br/>";
        } else { $("#txtNumeroDocIdentidad").removeClass("valorObligatorio"); }
    }
    if (idTipoDocIdentidad == ID_TIPO_IDENTIDAD_RUC) { // RUC
        if ($("#txtPrimerNombre").val() == "") {
            $("#txtPrimerNombre").addClass("valorObligatorio");
            mensaje += "* Ingrese la razón social.";
            mensaje += "<br/>";
        }
    } else {
        if ($("#txtApellidoPaterno").val() == "") {
            $("#txtApellidoPaterno").addClass("valorObligatorio");
            mensaje += "* Ingrese el apellido paterno.";
            mensaje += "<br/>";
        }
        //if ($("#txtApellidoMaterno").val() == "") {
        //    $("#txtApellidoMaterno").addClass("valorObligatorio");
        //    mensaje += "* Ingrese el apellido materno.";
        //    mensaje += "<br/>";
        //}
        let apellidoMaterno = $.trim($("#txtApellidoMaterno").val());
        if (apellidoMaterno !== "") {
            if (!$("#txtApellidoMaterno").hasClass("valorObligatorio")) {
                $("#txtApellidoMaterno").removeClass("valorObligatorio");
            }
        } else {
            $("#txtApellidoMaterno").removeClass("valorObligatorio");
        }

        if ($("#txtPrimerNombre").val() == "") {
            $("#txtPrimerNombre").addClass("valorObligatorio");
            mensaje += "* Ingrese el primer nombre.";
            mensaje += "<br/>";
        }
        if ($("#txtFechaNacimiento").val() == "") {
            $("#txtFechaNacimiento").addClass("valorObligatorio");
            mensaje += "* Ingrese la fecha de nacimiento.";
            mensaje += "<br/>";
        }
        var idGenero = $("#ddlTipoGenero").val();
        if (isNullOrEmptyOrUndefined(idGenero)) {
            $("#ddlTipoGenero").addClass("valorObligatorio");
            mensaje += "* Seleccione el sexo.";
            mensaje += "<br/>";
        } else { $("#ddlTipoGenero").removeClass("valorObligatorio"); }

        var idEstadoCivil = $("#ddlTipoEstadoCivil").val();
        if (isNullOrEmptyOrUndefined(idEstadoCivil)) {
            $("#ddlTipoEstadoCivil").addClass("valorObligatorio");
            mensaje += "* Seleccione el estado civil.";
            mensaje += "<br/>";
        } else { $("#ddlTipoEstadoCivil").removeClass("valorObligatorio"); }
    }






    var idActividadEcono = $("#ddlActividadEconomica").val();
    if (isNullOrEmptyOrUndefined(idActividadEcono)) {
        $("#ddlActividadEconomica").addClass("valorObligatorio");
        mensaje += "* Seleccione la actividad económica .";
        mensaje += "<br/>";
    } else { $("#ddlActividadEconomica").removeClass("valorObligatorio"); }

    if ($("#txtCorreo").val() != "") {
        var email = $.trim($("#txtCorreo").val());
        if (!validateEmail(email)) {
            $("#txtCorreo").addClass("valorObligatorio");
            mensaje += "* Ingrese un correo electrónico válido.";
            mensaje += "<br/>";
        } else {
            $("#txtCorreo").removeClass("valorObligatorio");
        }
    }
    var txtTelefono = $("#txtTelefono").val();
    if (txtTelefono != "") {
        var numConErrorD = validarNumeroTelefonoFijo(txtTelefono);
        if (numConErrorD) {
            $("#txtTelefono").addClass("valorObligatorio");
            mensaje += "* El número de telefono es inválido";
            mensaje += "<br/>";
        } else { $("#txtTelefono").removeClass("valorObligatorio"); }
    }

    var celular = $("#txtCelular").val();
    if (celular !== "") {
        var numConError = validarnumeroCelular(celular);
        if (numConError) {
            $("#txtCelular").addClass("valorObligatorio");
            mensaje += "* El número de celular es inválido";
            mensaje += "<br/>";
        } else { $("#txtCelular").removeClass("valorObligatorio"); }
    }

    var idDepartamento = $("#ddlDepartamento").val();
    if (isNullOrEmptyOrUndefined(idDepartamento)) {
        $("#ddlDepartamento").addClass("valorObligatorio");
        mensaje += "* Seleccione el departamento.";
        mensaje += "<br/>";
    } else { $("#ddlDepartamento").removeClass("valorObligatorio"); }

    var idProvincia = $("#ddlProvincia").val();
    if (isNullOrEmptyOrUndefined(idProvincia)) {
        $("#ddlProvincia").addClass("valorObligatorio");
        mensaje += "* Seleccione la provincia.";
        mensaje += "<br/>";
    } else { $("#ddlProvincia").removeClass("valorObligatorio"); }

    var idDistrito = $("#ddlDistrito").val();
    if (isNullOrEmptyOrUndefined(idDistrito)) {
        $("#ddlDistrito").addClass("valorObligatorio");
        mensaje += "* Seleccione el distrito.";
        mensaje += "<br/>";
    } else { $("#ddlDistrito").removeClass("valorObligatorio"); }


    var ddlTipoVia = $("#ddlTipoVia").val();
    if (isNullOrEmptyOrUndefined(ddlTipoVia)) {
        $("#ddlTipoVia").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de vía.";
        mensaje += "<br/>";
    } else { $("#ddlTipoVia").removeClass("valorObligatorio"); }

    var txtNombreVia = $("#txtNombreVia").val();
    if (txtNombreVia === "") {
        $("#txtNombreVia").addClass("valorObligatorio");
        mensaje += "* Ingrese el nombre de la vía.";
        mensaje += "<br/>";
    } else { $("#txtNombreVia").removeClass("valorObligatorio"); }

    var ddlTipoNumero = $("#ddlTipoNumero").val();
    if (isNullOrEmptyOrUndefined(ddlTipoNumero)) {
        $("#ddlTipoNumero").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de número.";
        mensaje += "<br/>";
    } else { $("#ddlTipoNumero").removeClass("valorObligatorio"); }

    var txtNombreNumero = $("#txtNombreNumero").val();
    if (txtNombreNumero === "") {
        $("#txtNombreNumero").addClass("valorObligatorio");
        mensaje += "* Ingrese el valor tipo de número.";
        mensaje += "<br/>";
    } else { $("#txtNombreNumero").removeClass("valorObligatorio"); }


    var idDepartamentoD = $("#ddlDepartamentoRiesg").val();
    if (isNullOrEmptyOrUndefined(idDepartamentoD)) {
        $("#ddlDepartamentoRiesg").addClass("valorObligatorio");
        mensaje += "* Seleccione el departamento del riesgo.";
        mensaje += "<br/>";
    } else { $("#ddlDepartamentoRiesg").removeClass("valorObligatorio"); }

    var idProvinciaD = $("#ddlProvinciaRiesg").val();
    if (isNullOrEmptyOrUndefined(idProvinciaD)) {
        $("#ddlProvinciaRiesg").addClass("valorObligatorio");
        mensaje += "* Seleccione la provincia del riesgo.";
        mensaje += "<br/>";
    } else { $("#ddlProvinciaRiesg").removeClass("valorObligatorio"); }

    var idDistritoD = $("#ddlDistritoRiesg").val();
    if (isNullOrEmptyOrUndefined(idDistritoD)) {
        $("#ddlDistritoRiesg").addClass("valorObligatorio");
        mensaje += "* Seleccione el distrito del riesgo.";
        mensaje += "<br/>";
    } else { $("#ddlDistritoRiesg").removeClass("valorObligatorio"); }

    var ddlTipoViaRiesg = $("#ddlTipoViaRiesg").val();
    if (isNullOrEmptyOrUndefined(ddlTipoViaRiesg)) {
        $("#ddlTipoViaRiesg").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de vía del riesgo";
        mensaje += "<br/>";
    } else { $("#ddlTipoViaRiesg").removeClass("valorObligatorio"); }

    var txtNombreViaRiesg = $("#txtNombreViaRiesg").val();
    if (txtNombreViaRiesg === "") {
        $("#txtNombreViaRiesg").addClass("valorObligatorio");
        mensaje += "* Ingrese el nombre de la vía del riesgo";
        mensaje += "<br/>";
    } else { $("#txtNombreViaRiesg").removeClass("valorObligatorio"); }

    var ddlTipoNumeroRiesg = $("#ddlTipoNumeroRiesg").val();
    if (isNullOrEmptyOrUndefined(ddlTipoNumeroRiesg)) {
        $("#ddlTipoNumeroRiesg").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de número del riesgo.";
        mensaje += "<br/>";
    } else { $("#ddlTipoNumeroRiesg").removeClass("valorObligatorio"); }

    var txtNombreViaRiesg = $("#txtNombreNumeroRiesg").val();
    if (txtNombreViaRiesg === "") {
        $("#txtNombreNumeroRiesg").addClass("valorObligatorio");
        mensaje += "* Ingrese el valor tipo de número de riesgo.";
        mensaje += "<br/>";
    } else { $("#txtNombreNumeroRiesg").removeClass("valorObligatorio"); }

    var valor = $("#txtAnioConst").val();
    var valorNumero = parseInt(valor, 10);
    var anioActual = new Date().getFullYear(); // Obtener el año actual

    // Validar si el campo está vacío
    if (valor === "") {
        $("#txtAnioConst").addClass("valorObligatorio");
        mensaje += "* Ingrese el año de construcción.";
        mensaje += "<br/>";
    } else {
        // Limpiar la clase de error si el campo no está vacío
        $("#txtAnioConst").removeClass("valorObligatorio");

        // Validar si el valor es un número y está en el rango de 1960 a año actual
        if (isNaN(valorNumero) || valorNumero < 1960 || valorNumero > anioActual) {
            $("#txtAnioConst").addClass("valorObligatorio");
            mensaje += "* El año debe ser un número entre 1960 y " + anioActual + ".";
            mensaje += "<br/>";
        } else {
            $("#txtAnioConst").removeClass("valorObligatorio");
        }
    }


    var ipTipoUso = $("#ddlTipoUsoEdif").val();
    if (isNullOrEmptyOrUndefined(ipTipoUso)) {
        $("#ddlTipoUsoEdif").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de uso de edificación.";
        mensaje += "<br/>";
    } else { $("#ddlTipoUsoEdif").removeClass("valorObligatorio"); }

    var idTipoMaterial = $("#ddlTipoMaterialEdif").val();
    if (isNullOrEmptyOrUndefined(idTipoMaterial)) {
        $("#ddlTipoMaterialEdif").addClass("valorObligatorio");
        mensaje += "* Seleccione el tipo de material del negocio.";
        mensaje += "<br/>";
    } else {
        $("#ddlTipoMaterialEdif").removeClass("valorObligatorio");
    }

    var valor = $("#txtPisosEdif").val();
    var valorNumero = parseInt(valor, 10);

    // Validar si el campo está vacío
    if (valor === "") {
        $("#txtPisosEdif").addClass("valorObligatorio");
        mensaje += "* Ingrese el número de pisos del negocio.";
        mensaje += "<br/>";
    } else {
        // Limpiar la clase de error si el campo no está vacío
        $("#txtPisosEdif").removeClass("valorObligatorio");

        // Validar si el valor es un número y está en el rango de 1 a 41
        if (isNaN(valorNumero) || valorNumero < 1 || valorNumero > 41) {
            $("#txtPisosEdif").addClass("valorObligatorio");
            mensaje += "* El número número de pisos va entre 1 y 41.";
            mensaje += "<br/>";
        } else {
            $("#txtPisosEdif").removeClass("valorObligatorio");
        }
    }

    //if ($("#txtPisosEdif").val() == "") {
    //    $("#txtPisosEdif").addClass("valorObligatorio");
    //    mensaje += "* Ingrese los pisos del negocio.";
    //    mensaje += "<br/>";
    //} else {
    //    $("#txtPisosEdif").removeClass("valorObligatorio");
    //}

    var validValues = ['0', '1', '2'];
    var valorSotano = $("#txtSotanosEdif").val()
    if (!validValues.includes(valorSotano)) {
        $("#txtSotanosEdif").addClass("valorObligatorio");
        mensaje += "* Ingrese los valores validos 0, 1 ó 2. para el número de sotanos";        
        mensaje += "<br/>";
    } else {
        $("#txtSotanosEdif").removeClass("valorObligatorio");
    }

    if ($("#txtDireccionRiesgo").val() == "") {
        $("#txtDireccionRiesgo").addClass("valorObligatorio");
        mensaje += "* Ingrese la descripción.";
        mensaje += "<br/>";
    } else {
        $("#txtDireccionRiesgo").removeClass("valorObligatorio");
    }

    if ($("#txtBienesPropios").val() == "") {
        $("#txtBienesPropios").addClass("valorObligatorio");
        mensaje += "* Ingrese bienes contenidos propios del negocio.";
        mensaje += "<br/>";
    } else {
        $("#txtBienesPropios").removeClass("valorObligatorio");
    }

    if ($("#txtExistenciaPropias").val() == "") {
        $("#txtExistenciaPropias").addClass("valorObligatorio");
        mensaje += "* Ingrese la existencias propias del negocio.";
        mensaje += "<br/>";
    } else {
        $("#txtExistenciaPropias").removeClass("valorObligatorio");
    }
    return mensaje;
}
